"""Backend switch smoke checks; do not expose or alter private saves."""
from pathlib import Path
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from urllib.request import urlopen
import pytest

ROOT = Path(__file__).resolve().parents[1]


def test_backend_menu_exists_at_footer_and_defaults_to_native():
    html = (ROOT / 'pvz-portable.html').read_text()
    assert 'id="pvz-engine-select"' in html
    assert html.index('id="pvz-engine-select"') < html.index('</footer>')
    assert html.count('data-pvz-backend="wasm"') == 1
    assert html.count('data-pvz-backend="js"') == 1
    assert 'Native WASM backend' in html
    assert 'JS Fallback backend (experimental)' in html
    assert "window.pvzBackend = backend" in html
    assert "pvz-backend-v1" in html


def test_standalone_emscripten_is_loaded_only_in_js_mode():
    html = (ROOT / 'pvz-portable.html').read_text()
    assert "var jsBackend=window.pvzBackend==='js'" in html
    assert "engineScript.src=jsBackend?'pvz-portable-engine-fallback.js':'pvz-portable.js'" in html
    assert '<script async="" src="pvz-portable.js"></script>' not in html
    assert 'PvZJsFallback.createExports' not in html
    js = ROOT / 'pvz-portable-engine-fallback.js'
    assert 8_000_000 < js.stat().st_size < 20_000_000
    with js.open('r', encoding='utf-8') as f:
        head = f.read(700)
    assert head.startswith('var Module=typeof Module')
    assert 'import * as' not in head
    assert '__pvz_flat_loop' in js.read_text(encoding='utf-8')  # Astra's newer flattener uses suffixed loop labels


@pytest.mark.skipif(not shutil.which('node'), reason='Node.js required')
def test_generated_js_parses_with_small_v8_stack():
    cmd = ['node', '--stack-size=512', '--check', str(ROOT / 'pvz-portable-engine-fallback.js')]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    assert result.returncode == 0, result.stderr[:800]


@pytest.mark.skipif(not shutil.which('node'), reason='Node.js required')
def test_js_backend_initializes_with_small_v8_stack():
    # --check alone can pass while a browser overflows parsing/evaluating the
    # wasm2js factory. Exercise the real runtime, without native WebAssembly.
    script = r'''
const assert = require('node:assert/strict');
const vm = require('node:vm');
const source = require('node:fs').readFileSync(process.argv[1], 'utf8');
const timeout = setTimeout(() => {
    console.error('onRuntimeInitialized did not fire');
    process.exit(1);
}, 15000);
const context = {
    console, setTimeout, clearTimeout, TextDecoder, TextEncoder, performance,
    WebAssembly: undefined,
    Module: {
        noInitialRun: true,
        onRuntimeInitialized() {
            const module = context.Module;
            assert.equal(typeof module.callMain, 'function');
            assert.equal(typeof module._main, 'function');
            module.FS.writeFile('/backend-smoke.txt', 'JS runtime ready');
            assert.equal(module.FS.readFile('/backend-smoke.txt', {encoding: 'utf8'}),
                         'JS runtime ready');
            module.FS.unlink('/backend-smoke.txt');
            clearTimeout(timeout);
            console.log('JS_RUNTIME_READY');
        }
    }
};
try {
    vm.runInNewContext(source, context, {filename: process.argv[1]});
} catch (error) {
    console.error(error.name + ': ' + error.message);
    process.exit(1);
}
'''
    result = subprocess.run(
        ['node', '--stack-size=256', '--unhandled-rejections=strict', '-e', script,
         str(ROOT / 'pvz-portable-engine-fallback.js')],
        capture_output=True, text=True, timeout=25,
    )
    assert result.returncode == 0, result.stderr[:1200]
    assert 'JS_RUNTIME_READY' in result.stdout


def test_backend_static_route_is_public_but_private_data_is_not():
    with tempfile.TemporaryDirectory() as datadir:
        s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
        env = {**os.environ, 'PVZ_DATA_DIR': datadir}
        proc = subprocess.Popen([sys.executable, str(ROOT / 'server.py'), '--host', '127.0.0.1', '--port', str(port)],
                                env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            url = 'http://127.0.0.1:' + str(port)
            for attempt in range(30):
                try:
                    with urlopen(url, timeout=1) as result:
                        assert result.status == 200
                    break
                except Exception:
                    if attempt == 29: raise
                    time.sleep(0.1)
            with urlopen(url + '/pvz-portable-engine-fallback.js', timeout=10) as result:
                assert result.status == 200
                assert result.headers['Content-Type'].startswith('application/javascript')
                assert result.headers['Content-Length'] == str((ROOT / 'pvz-portable-engine-fallback.js').stat().st_size)
                assert result.read(250).startswith(b'var Module=typeof Module')
            with pytest.raises(Exception):
                urlopen(url + '/server_data/saves/private.zip', timeout=3)
        finally:
            proc.terminate()
            proc.wait(timeout=5)
