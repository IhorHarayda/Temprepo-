const fs=require('fs');const vm=require('vm');const assert=require('assert');const crypto=require('crypto');
const text=fs.readFileSync(__dirname+'/../server-features.js','utf8');
const start=text.indexOf('  async function downloadResourceArchive(item) {');
const end=text.indexOf('  async function loadSelectedResource(item) {',start);
assert(start>0&&end>start);
const fn=text.slice(start,end);
const total=2*1048576+133;
const sample=Buffer.alloc(total);for(let i=0;i<total;i++)sample[i]=i%251;
const stats={calls:0,failures:0,progress:[]};const attempts={};
const stub=async (_path,opts)=>{
  stats.calls++;
  const range=opts.headers.Range;
  const m=/bytes=(\d+)-(\d+)/.exec(range);
  const a=Number(m[1]),b=Number(m[2]);
  attempts[a]=(attempts[a]||0)+1;
  if(a===1048576 && attempts[a]===1) {stats.failures++; throw Error('Failed to fetch (simulated mid-transfer disconnect)');}
  return new Response(sample.subarray(a,b+1),{status:206,headers:{'Content-Range':`bytes ${a}-${b}/${total}`,ETag:'"fixed-v1"'}});
};
const globals={Blob,Response,Uint8Array,AbortController,setTimeout,clearTimeout,console,encodeURIComponent,serverFetch:stub,readableSize:n=>`${n} B`,setStatus:s=>stats.progress.push(s)};
vm.createContext(globals);
vm.runInContext(fn+'\nthis.downloadResourceArchive=downloadResourceArchive;',globals);
(async()=>{
  const archive=await globals.downloadResourceArchive({id:'test.zip',name:'test',size:total});
  const actual=Buffer.from(await archive.arrayBuffer());
  assert.deepEqual(actual,sample);
  assert.equal(stats.calls,4);assert.equal(stats.failures,1);
  console.log('CHUNK CLIENT OK:',stats.calls,'requests; 1 simulated network interruption, full data identical');
  // Malformed response must fail, not produce silently truncated ZIP.
  globals.serverFetch=async(_p,opts)=>new Response(sample.subarray(0,8),{status:206,headers:{'Content-Range':opts.headers.Range.replace('=', ' ')+'/'+total}});
  let failed=false;
  try{await globals.downloadResourceArchive({id:'test.zip',name:'test',size:total});}catch(e){failed=/4 attempts/.test(e.message)}
  assert(failed);
  console.log('TRUNCATED CHUNK: rejected after retries');
  globals.serverFetch=async()=>new Response(sample,{status:200,headers:{'Content-Type':'application/zip'}});
  const legacy=await globals.downloadResourceArchive({id:'test.zip',name:'test',size:total});
  assert.deepEqual(Buffer.from(await legacy.arrayBuffer()),sample);
  console.log('OLD SERVER: full response accepted');
})().catch(e=>{console.error(e);process.exit(1)});
