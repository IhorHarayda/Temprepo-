"""Visual-mode isolation tests. Run: python3 -m pytest tests -q"""
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from urllib.request import urlopen

import pytest

ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / 'pvz-portable.html').read_text(encoding='utf-8')


def test_modes_preserve_main_controls():
    for item in ('browse-zip-btn', 'browse-folder-btn', 'server-resource-btn',
                 'upload-save-import-btn', 'upload-save-import-dir-btn',
                 'server-save-import-btn', 'server-save-upload-btn',
                 'upload-save-clear-btn', 'server-recovery-details',
                 'server-picker-history-btn', 'server-autobackup-checkbox',
                 'canvas-container', 'pvz-mode-lite', 'pvz-mode-glass'):
        assert f'id="{item}"' in HTML, f'Missing existing or mode control: {item}'


def test_low_end_no_heavy_decor_and_skips_optics():
    lite = (ROOT / 'low-end.css').read_text(encoding='utf-8')
    assert len(lite.encode()) < 20_000
    assert 'background-image:url(' not in lite
    assert '@keyframes' not in lite
    assert 'backdrop-filter:none!important' in lite
    assert "document.documentElement.getAttribute('data-pvz-mode') === 'low'" in HTML
    assert "mode==='low'?'low-end.css':'liquid-glass.css'" in HTML
    assert "?ui=low" in (ROOT / 'README_LOW_END.md').read_text()


def test_low_end_stylesheet_is_served_without_exposing_private_files():
    with tempfile.TemporaryDirectory() as temp:
        with socket.socket() as s:
            s.bind(('127.0.0.1', 0))
            port = s.getsockname()[1]
        env = {**os.environ, 'PVZ_DATA_DIR': temp}
        proc = subprocess.Popen([sys.executable, str(ROOT / 'server.py'),
                                 '--host', '127.0.0.1', '--port', str(port)],
                                cwd=ROOT, env=env,
                                stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        try:
            for _ in range(50):
                try:
                    with urlopen(f'http://127.0.0.1:{port}/low-end.css', timeout=1) as res:
                        assert res.status == 200
                        assert res.headers['Content-Type'].startswith('text/css')
                        assert b'No images, filters' in res.read()
                    break
                except OSError:
                    if proc.poll() is not None:
                        raise RuntimeError(proc.stderr.read().decode())
                    time.sleep(.1)
            else:
                pytest.fail('server did not respond')
            with urlopen(f'http://127.0.0.1:{port}/') as res:
                assert b'id="pvz-mode-lite"' in res.read()
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()


@pytest.mark.skipif(not shutil.which('node'), reason='Node.js needed for JavaScript selection test')
def test_mode_selection_works_before_load_and_remembers_choice():
    # Execute the real small HEAD script with a fake browser context.
    pattern = r'<link id="pvz-visual-stylesheet" rel="stylesheet"/><script>(.*?)</script>'
    match = re.search(pattern, HTML, re.S)
    assert match, 'Pre-paint mode chooser missing'
    node_code = r'''
const vm = require('vm');
const script = process.argv[1];
function run(stored,memory,search,androidCores) {
  let saved=stored, attr='', href='';
  const doc={documentElement:{setAttribute:(k,v)=>{if(k==='data-pvz-mode')attr=v;}},
             getElementById:()=>({set href(v){href=v;}})};
  const ctx={
    document:doc, navigator:{deviceMemory:memory,userAgent:androidCores?'Android':'Linux',hardwareConcurrency:androidCores||8},
    location:{search}, URLSearchParams,
    localStorage:{getItem:()=>saved,setItem:(_,v)=>{saved=v;}}, window:{}
  };
  vm.runInNewContext(script,ctx);
  return [attr,href,saved,ctx.window.pvzVisualMode];
}
const cases=[
 ['low',8,'',0,'low'], ['glass',2,'',0,'glass'],
 [null,2,'',0,'low'], [null,8,'',0,'glass'],
 [null,undefined,'',4,'low'],
 ['glass',8,'?ui=low',0,'low'], ['low',2,'?ui=glass',0,'glass']
];
for(const [stored,mem,query,cores,expected] of cases) {
  let got=run(stored,mem,query,cores);
  if(got[0]!==expected||got[1]!== (expected==='low'?'low-end.css':'liquid-glass.css')||got[3]!==expected) {
     throw new Error(JSON.stringify({stored,mem,query,expected,got}));
  }
}
'''
    result = subprocess.run(['node', '-e', node_code, match.group(1)],
                            capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
