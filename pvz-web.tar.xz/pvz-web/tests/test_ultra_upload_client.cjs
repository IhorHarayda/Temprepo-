// Real ES5 Ultra client, simulated DOM/XHR/FS. No WASM is involved.
const vm=require('vm'),fs=require('fs'),assert=require('assert');
const elems={};
for(const id of ['ultra-start','ultra-save','ultra-message','ultra-slot','ultra-game','canvas','ultra-autobackup']) {
  elems[id]={textContent:'',value:id==='ultra-slot'?'manual':'',style:{},disabled:id==='ultra-save',addEventListener(type,handler){this['on'+type]=handler;},focus(){}};
}
const fileA=Uint8Array.from([85,115,101,114,0,255]),fileB=Uint8Array.from({length:95000},(_,i)=>i%256);
const files={};let pending={},saved={},requests=[];
const FS={
  mkdir(){},
  writeFile(path,data){files[path]=Uint8Array.from(data);},
  readFile(path){if(!files[path])throw Error('Missing '+path);return files[path];},
  readdir(path){const names=new Set(['.','..']);for(const f of Object.keys(files))if(f.startsWith(path+'/'))names.add(f.slice(path.length+1).split('/')[0]);return [...names];},
  stat(p){return {mode:Object.keys(files).some(f=>f.startsWith(p+'/'))?16877:33188};},
  isDir(mode){return mode===16877;},
};
const sandbox={console,Uint8Array,setTimeout,setInterval,clearTimeout,encodeURIComponent,decodeURIComponent,PVZ_ULTRA_CSRF:'a'.repeat(32),PVZ_ULTRA_HAS_KEY:true,PVZ_ULTRA_HAS_RESOURCE:true,
  document:{getElementById: id=>elems[id],getElementsByTagName:()=>[{appendChild(el){
    if(el.src.endsWith('/manifest.js')){
       sandbox.PVZ_ULTRA_RESOURCE_FILES=[]; sandbox.PVZ_ULTRA_SAVE_FILES=[];
    } else {
       sandbox.Module.FS=FS;
       sandbox.Module.callMain=function(){FS.writeFile('/saves/userdata/users.dat',fileA);FS.writeFile('/saves/userdata/game1_0.v4',fileB);};
       sandbox.Module.onRuntimeInitialized();
    }
    setTimeout(()=>el.onload&&el.onload(),0);
  }}],createElement:()=>({})},
};
sandbox.window=sandbox;
class XMLHttpRequest {
 constructor(){this.status=0;this.readyState=0;this.responseText='';this.headers={};}
 open(method,url){this.method=method;this.url=url;}
 setRequestHeader(k,v){this.headers[k]=v;}
 send(payload){
   requests.push([this.method,this.url]);
   setTimeout(()=>{
     try{
       if(this.url==='/ultra/begin-save'){pending={};this.status=200;this.responseText='OK';}
       else if(this.url==='/ultra/save-chunk'){
         const data=new URLSearchParams(payload);
         assert.strictEqual(data.get('csrf'),sandbox.PVZ_ULTRA_CSRF);
         const p=data.get('path'),offset=+data.get('offset'),bytes=Buffer.from(data.get('data'),'base64');
         assert.strictEqual(offset,(pending[p]||Buffer.alloc(0)).length);
         assert(bytes.length<=48*1024);
         pending[p]=Buffer.concat([pending[p]||Buffer.alloc(0),bytes]);this.status=200;this.responseText='OK';
       } else if(this.url==='/ultra/commit-save'){
         saved=pending;this.status=200;this.responseText='OK';
       } else {this.status=500;this.responseText='unhandled';}
     } catch(e) {this.status=500;this.responseText=String(e);}
     this.readyState=4;this.onreadystatechange();
   },0);
 }
}
sandbox.XMLHttpRequest=XMLHttpRequest;
vm.runInNewContext(fs.readFileSync(require('path').join(__dirname,'..','ultra-engine.js'),'utf8'),sandbox);
(async()=>{
  elems['ultra-start'].onclick();
  for(let i=0;i<200;i++){
    if(elems['ultra-message'].textContent?.indexOf('Game started')>=0) break;
    await new Promise(r=>setTimeout(r,5));
  }
  assert.match(elems['ultra-message'].textContent,/Game started/);
  elems['ultra-save'].onclick();
  for(let i=0;i<250;i++){
    if(elems['ultra-message'].textContent?.indexOf('Server backup complete')>=0) break;
    await new Promise(r=>setTimeout(r,5));
  }
  assert.match(elems['ultra-message'].textContent,/Server backup complete/);
  assert.deepStrictEqual(saved['userdata/users.dat'],Buffer.from(fileA));
  assert.deepStrictEqual(saved['userdata/game1_0.v4'],Buffer.from(fileB));
  assert(requests.filter(x=>x[1]==='/ultra/save-chunk').length>=3);
  console.log('PASS Ultra button: Begin -> base64 chunks -> Commit; '+requests.length+' requests; 95006 saved bytes');
  process.exit(0);
})().catch(e=>{console.error(e);process.exit(1);});
