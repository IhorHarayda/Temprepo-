"""Compare generated control flow before and after flattening in a JS engine."""
import json
import shutil
import subprocess

import pytest

from flatten_wasm2js import flatten_source


def evaluate(source, inputs):
    result = subprocess.run(
        ['node', '-e', source + '\nconsole.log(JSON.stringify(' +
         json.dumps(inputs) + '.map(sample)));'],
        capture_output=True, text=True, timeout=10,
    )
    assert result.returncode == 0, result.stderr
    return json.loads(result.stdout)


@pytest.mark.skipif(not shutil.which('node'), reason='Node.js required')
@pytest.mark.parametrize('source,inputs', [
    # Bare breaks immediately before a removed closing brace still need to be
    # rewritten; the compiled engine omits semicolons at these segment ends.
    ('''function sample(x){var out=[];
    a:{b:{c:{out.push(0);if(x===1){break c}}
      out.push(1);break a
    }out.push(2)}out.push(3);return out}''', [0, 1]),
    # Fallthrough and exits to the innermost, middle and outermost blocks.
    ('''function sample(x){var out=[];
    a:{b:{c:{d:{out.push(0);
      if(x===1){break d}if(x===2){break b}if(x===3){break a}
    }out.push(1);if(x===4){break b}}out.push(2)}out.push(3)}
    out.push(4);return out}''', list(range(5))),
    # Replacing one jump must remain one statement in unbraced conditions.
    ('''function sample(x){var out=[];
    a:{b:{c:{if(x===1)break b;else out.push(0);
    if(x===2)break a;out.push(1)}out.push(2)}out.push(3)}
    return out}''', [0, 1, 2]),
    # Jumps to an enclosing loop must still target that loop.
    ('''function sample(x){var out=[];
    outer:for(var i=0;i<4;i++){
      a:{b:{c:{if(i===1){if(x===0){continue outer}if(x===1){break outer}}
      out.push(i)}out.push(10+i)}out.push(20+i)}
    }return out}''', [0, 1, 2]),
    # The engine has unlabelled jumps to an already labeled enclosing loop.
    ('''function sample(x){var out=[];
    outer:for(var i=0;i<4;i++){
      a:{b:{c:{if(i===1){if(x===0){continue}if(x===1){break}}
      out.push(i)}out.push(10+i)}out.push(20+i)}
    }return out}''', [0, 1, 2]),
    # Unlabelled jumps inside a contained loop retain their original targets.
    ('''function sample(x){var out=[];
    a:{b:{c:{for(var i=0;i<5;i++){
      if(i===1){continue}if(i===x){break}out.push(i)
    }if(x===4){break b}}out.push(10)}out.push(20)}
    return out}''', [0, 2, 4, 9]),
    # Nested and separate ladders need independent state variables and labels.
    ('''function sample(x){var out=[];
    a:{b:{c:{out.push(0);
      d:{e:{f:{if(x===1){break e}if(x===2){break b}out.push(1)}
      out.push(2)}out.push(3)}out.push(4)
    }out.push(5)}out.push(6)}
    g:{h:{j:{if(x===3){break h}out.push(7)}out.push(8)}out.push(9)}
    return out}''', [0, 1, 2, 3]),
])
def test_flattening_preserves_control_flow(source, inputs):
    flattened = flatten_source(source, min_labels=3)
    assert flattened != source
    assert evaluate(flattened, inputs) == evaluate(source, inputs)
    assert flatten_source(flattened, min_labels=3) == flattened


@pytest.mark.skipif(not shutil.which('node'), reason='Node.js required')
def test_strings_and_comments_are_not_rewritten():
    literal = 'a:{b:{c:{ break a; }}}'
    comment = '/* a:{b:{c:{ break b; }}} */'
    source = ('function sample(x){var out=[' + json.dumps(literal) + '];' +
              comment + '\n// a:{b:{c:{ break c; }}}\n' +
              'a:{/* ladder header: break a; } */b:{c:{/* body start */' +
              'out.push("break a; }");if(x){break b}}' +
              'out.push(1)}out.push(2)}return out}')
    flattened = flatten_source(source, min_labels=3)
    assert json.dumps(literal) in flattened
    assert comment in flattened
    assert '// a:{b:{c:{ break c; }}}\n' in flattened
    assert '/* ladder header: break a; } */' in flattened
    assert '/* body start */' in flattened
    assert evaluate(flattened, [0, 1]) == evaluate(source, [0, 1])


def test_default_threshold_handles_multiple_ladders_without_known_label_names():
    ladder = lambda prefix: ''.join(f'{prefix}{i}:{{' for i in range(80)) + '}' * 80
    source = 'function sample(){' + ladder('first') + ladder('second') + 'return 7}'
    flattened = flatten_source(source)
    assert 'first0:{first1:{' not in flattened
    assert 'second0:{second1:{' not in flattened
    assert flatten_source(flattened) == flattened


@pytest.mark.parametrize('jump', ['break', 'continue'])
def test_refuses_to_change_the_target_of_an_unlabelled_jump(jump):
    source = 'function sample(){while(true){a:{b:{c:{' + jump + ';}}}}}'
    with pytest.raises(ValueError, match='Unlabelled jump'):
        flatten_source(source, min_labels=3)
