"""Run with: python3 -m pytest tests -q (pytest is optional, not needed to serve)."""
import io
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import tempfile
import time
import zipfile

import pytest
import requests

ROOT = Path(__file__).resolve().parents[1]
TOKEN = 'test-secret-that-is-long-enough'
KEY_A = 'a' * 64
KEY_B = 'b' * 64


def zip_bytes(files: dict[str, bytes]):
    memory = io.BytesIO()
    with zipfile.ZipFile(memory, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for path, data in files.items():
            archive.writestr(path, data)
    return memory.getvalue()


@pytest.fixture(scope='module')
def site():
    with tempfile.TemporaryDirectory() as temp:
        data = Path(temp)
        resource_dir = data / 'resources'
        resource_dir.mkdir()
        os.link(ROOT / 'server_data' / 'resources' / 'pvz-portable-wasm.zip', resource_dir / 'pvz-portable-wasm.zip')
        with socket.socket() as s:
            s.bind(('127.0.0.1', 0))
            port = s.getsockname()[1]
        env = {**os.environ, 'PVZ_SERVER_TOKEN': TOKEN, 'PVZ_DATA_DIR': temp}
        proc = subprocess.Popen([sys.executable, str(ROOT / 'server.py'), '--port', str(port)],
                                env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        base = f'http://127.0.0.1:{port}'
        for _ in range(50):
            if proc.poll() is not None:
                raise RuntimeError(proc.stderr.read().decode())
            try:
                requests.get(base + '/', timeout=0.25)
                break
            except requests.RequestException:
                time.sleep(0.1)
        else:
            raise RuntimeError('Backend failed to start')
        yield base
        proc.terminate()
        try: proc.wait(timeout=4)
        except subprocess.TimeoutExpired: proc.kill()


def h(key=KEY_A, token=TOKEN):
    return {'X-PvZ-Server-Token': token, 'X-PvZ-Save-Key': key}


def test_public_and_protected_routes(site):
    page = requests.get(site + '/')
    assert page.status_code == 200
    assert 'Import Server Local Save' in page.text
    assert 'Import Server Game Files' in page.text
    assert requests.get(site + '/pvz-portable.wasm').headers['Content-Type'] == 'application/wasm'
    assert requests.get(site + '/server.py').status_code == 404
    assert requests.get(site + '/server_data/resources/pvz-portable-wasm.zip').status_code == 404
    assert requests.get(site + '/api/resources').status_code == 401
    assert requests.get(site + '/api/resources', headers=h(token='bad')).status_code == 401
    resources = requests.get(site + '/api/resources', headers=h()).json()['resources']
    assert len(resources) == 1
    assert resources[0]['id'] == 'pvz-portable-wasm.zip'
    assert resources[0]['size'] > 30_000_000
    with requests.get(site + '/api/resources/pvz-portable-wasm.zip', headers=h(), stream=True) as response:
        assert response.status_code == 200
        assert response.headers['Content-Type'] == 'application/zip'
        assert next(response.iter_content(256))[:2] == b'PK'
    assert requests.get(site + '/api/resources/..%2fserver.py', headers=h()).status_code == 400


def test_save_roundtrip_and_isolation(site):
    body = zip_bytes({'userdata/users/user1.dat': b'plant progress', 'userdata/config.dat': b'valid config'})
    headers = {**h(), 'Content-Type': 'application/zip'}
    response = requests.post(site + '/api/saves/manual', headers=headers, data=body)
    assert response.status_code == 200, response.text
    assert response.json()['slot'] == 'manual'
    saves = requests.get(site + '/api/saves', headers=h()).json()['saves']
    assert len(saves) == 1
    assert saves[0]['slot'] == 'manual'
    assert 'updated_at' in saves[0]
    assert requests.get(site + '/api/saves/manual', headers=h()).content == body
    assert requests.get(site + '/api/saves', headers=h(key=KEY_B)).json()['saves'] == []
    assert requests.get(site + '/api/saves/manual', headers=h(key=KEY_B)).status_code == 404
    assert requests.get(site + '/api/saves', headers=h(key='bad')).status_code == 400
    assert requests.post(site + '/api/saves/%2e%2e', headers=headers, data=body).status_code == 400
    assert requests.delete(site + '/api/saves/manual', headers=h(key=KEY_B)).status_code == 404
    assert requests.delete(site + '/api/saves/manual', headers=h()).status_code == 200
    assert requests.get(site + '/api/saves', headers=h()).json()['saves'] == []


@pytest.mark.parametrize('contents', [
    {'../escape.txt': b'exploit'},
    {'userdata/../../escape': b'exploit'},
    {'saves/user.dat': b'wrong root'},
    {'userdata/': b''},
    {'/userdata/evil': b'bad'},
])
def test_reject_unsafe_saves(site, contents):
    response = requests.post(site + '/api/saves/bad',
                             headers={**h(), 'Content-Type': 'application/zip'},
                             data=zip_bytes(contents))
    assert response.status_code == 400, response.text


def test_reject_bad_upload(site):
    assert requests.post(site + '/api/saves/test', headers={**h(), 'Content-Type': 'application/zip'}, data=b'not a zip').status_code == 400
    assert requests.post(site + '/api/saves/test', headers={**h(), 'Content-Type': 'text/plain'}, data=b'not a zip').status_code == 415
    assert requests.post(site + '/api/saves/test', headers={**h(), 'Content-Type': 'application/zip'}, data=b'X' * (16 * 1024 * 1024 + 1)).status_code == 413


def test_history_keeps_ten_previous_versions_per_slot(site):
    slot = 'autosave'
    headers = {**h(), 'Content-Type': 'application/zip'}
    endpoint = site + f'/api/saves/{slot}'
    bodies = [zip_bytes({'userdata/level.dat': f'level-{i:02d}'.encode()}) for i in range(12)]

    initial = requests.post(endpoint, headers=headers, data=bodies[0])
    assert initial.status_code == 200, initial.text
    empty = requests.get(endpoint + '/history', headers=h())
    assert empty.status_code == 200
    assert empty.json()['history'] == []

    for i, body in enumerate(bodies[1:], 1):
        reply = requests.post(endpoint, headers=headers, data=body)
        assert reply.status_code == 200, reply.text
        assert reply.json()['history_count'] == min(i, 10)

    assert requests.get(endpoint, headers=h()).content == bodies[11]
    history = requests.get(endpoint + '/history', headers=h()).json()
    assert history['limit'] == 10
    assert len(history['history']) == 10
    assert [x['revision'] for x in history['history']] == sorted(
        [x['revision'] for x in history['history']], reverse=True)
    for item, expected in zip(history['history'], reversed(bodies[1:11])):
        assert 'created_at' in item
        assert requests.get(endpoint + '/history/' + item['revision'], headers=h()).content == expected
    # The oldest v0 is pruned. Ten *previous* versions remain plus v11 current.
    assert all(requests.get(endpoint + '/history/' + item['revision'], headers=h()).content != bodies[0]
               for item in history['history'])
    listing = requests.get(site + '/api/saves', headers=h()).json()['saves']
    current = next(x for x in listing if x['slot'] == slot)
    assert current['history_count'] == 10
    assert len([x for x in listing if x['slot'] == slot]) == 1


def test_history_is_private_immutable_and_bad_upload_does_not_rotate(site):
    endpoint = site + '/api/saves/autosave'
    history_url = endpoint + '/history'
    headers = {**h(), 'Content-Type': 'application/zip'}
    original_history = requests.get(history_url, headers=h()).json()['history']
    original_live = requests.get(endpoint, headers=h()).content

    assert requests.get(history_url, headers=h(key=KEY_B)).status_code == 404
    assert requests.get(history_url + '/' + original_history[0]['revision'], headers=h(key=KEY_B)).status_code == 404
    assert requests.get(history_url + '/%2e%2e/manual', headers=h()).status_code == 400
    assert requests.get(history_url + '/does-not-exist', headers=h()).status_code == 400
    assert requests.get(history_url + '/0' * 20, headers=h()).status_code == 400
    assert requests.post(endpoint, headers=headers, data=b'corrupted zip').status_code == 400
    assert requests.get(endpoint, headers=h()).content == original_live
    assert requests.get(history_url, headers=h()).json()['history'] == original_history

    # Downloading an older version must never change the live copy.
    _ = requests.get(history_url + '/' + original_history[-1]['revision'], headers=h()).content
    assert requests.get(endpoint, headers=h()).content == original_live


def test_delete_removes_current_save_and_history(site):
    headers = h()
    endpoint = site + '/api/saves/autosave'
    assert requests.delete(endpoint, headers=headers).status_code == 200
    assert requests.get(endpoint, headers=headers).status_code == 404
    assert requests.get(endpoint + '/history', headers=headers).status_code == 404
    assert not any(item['slot'] == 'autosave'
                   for item in requests.get(site + '/api/saves', headers=headers).json()['saves'])
