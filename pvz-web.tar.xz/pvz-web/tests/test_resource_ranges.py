"""Isolated tests for resumable resource ZIP downloads (no user save data)."""
import io
import os
import socket
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

import pytest
import requests

ROOT=Path(__file__).resolve().parents[1]
TOKEN='test-only-secret-key-123456789'

@pytest.fixture()
def server():
    with tempfile.TemporaryDirectory() as dirname:
        data=Path(dirname)
        resources=data/'resources';resources.mkdir()
        archive=resources/'game.zip'
        with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
            z.writestr('main.pak', bytes(range(256)) * 7000)
            z.writestr('properties/demo.xml', b'<test/>')
        with socket.socket() as s:
            s.bind(('127.0.0.1',0));port=s.getsockname()[1]
        env={**os.environ,'PVZ_DATA_DIR':str(data),'PVZ_SERVER_TOKEN':TOKEN}
        proc=subprocess.Popen([sys.executable,str(ROOT/'server.py'),'--port',str(port)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        url=f'http://127.0.0.1:{port}/api/resources/game.zip'
        for i in range(40):
            if proc.poll() is not None:raise RuntimeError('server exited early')
            try:
                requests.head(url,headers={'X-PvZ-Server-Token':TOKEN},timeout=.2)
                break
            except requests.RequestException:
                time.sleep(.05)
        else:raise RuntimeError('server did not start')
        yield url,archive.read_bytes()
        proc.terminate();proc.wait(timeout=5)

def test_chunk_range_and_auth(server):
    url,source=server
    headers={'X-PvZ-Server-Token':TOKEN}
    assert requests.get(url,headers={'Range':'bytes=0-99'}).status_code == 401
    head=requests.head(url,headers=headers)
    assert head.status_code==200 and int(head.headers['Content-Length'])==len(source)
    etag=head.headers['ETag']
    assert head.headers['Accept-Ranges']=='bytes'
    pieces=[]
    for a in range(0,len(source),1024):
        b=min(a+1023,len(source)-1)
        r=requests.get(url,headers={**headers,'Range':f'bytes={a}-{b}','If-Range':etag})
        assert r.status_code==206
        assert r.headers['Content-Range']==f'bytes {a}-{b}/{len(source)}'
        pieces.append(r.content)
    assert b''.join(pieces)==source
    invalid=requests.get(url,headers={**headers,'Range':f'bytes={len(source)}-{len(source)+10}'})
    assert invalid.status_code==416
    assert invalid.headers['Content-Range']==f'bytes */{len(source)}'
    assert requests.get(url,headers={**headers,'Range':'bytes=-9'}).status_code==416
    assert requests.get(url,headers={**headers,'Range':'bytes=1-2,4-5'}).status_code==416
    old=requests.get(url,headers={**headers,'Range':'bytes=0-9','If-Range':'"different"'})
    assert old.status_code==200 and old.content==source
