"""Ultra low-end UI: simulate old browsers that only submit HTML forms and follow links."""
import io
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import tempfile
import time
import zipfile

import pytest
import requests

ROOT=Path(__file__).resolve().parents[1]
TOKEN='test-ultra-token-with-enough-length'
KEY='b'*64


def zipped(files):
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for name,data in files.items():z.writestr(name,data)
    return stream.getvalue()


@pytest.fixture(scope='module')
def site():
    with tempfile.TemporaryDirectory() as d:
        data=Path(d);(data/'resources').mkdir()
        resource=zipped({'main.pak': b'pvz game data', 'properties/default.xml':b'<root/>'})
        (data/'resources'/'tiny-resources.zip').write_bytes(resource)
        with socket.socket() as sk:
            sk.bind(('127.0.0.1',0));port=sk.getsockname()[1]
        env={**os.environ,'PVZ_DATA_DIR':d,'PVZ_SERVER_TOKEN':TOKEN}
        proc=subprocess.Popen([sys.executable,str(ROOT/'server.py'),'--port',str(port)],env=env,
                              stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        url='http://127.0.0.1:'+str(port)
        for i in range(80):
            if proc.poll() is not None:raise RuntimeError(proc.stderr.read().decode())
            try:
                requests.get(url+'/',timeout=0.25);break
            except requests.RequestException:time.sleep(0.05)
        yield url
        proc.terminate();proc.wait(timeout=4)


def csrf(html):
    match=re.search(r'name="csrf" value="([0-9a-f]+)"',html)
    assert match,html[:2000]
    return match.group(1)


def login(site):
    s=requests.Session()
    form=s.get(site+'/ultra/')
    assert 'Server token' in form.text
    resp=s.post(site+'/ultra/login',data={'token':TOKEN})
    assert resp.status_code==200
    assert 'Server access: connected' in resp.text
    assert 'Ultra Low-end: ON' in resp.text
    return s,csrf(resp.text)


def test_server_forms_and_legacy_script(site):
    s,c=login(site)
    page=s.get(site+'/ultra/').text
    assert '<form method="post" action="/ultra/select-resource">' in page
    assert '<input type="password"' not in page
    assert 'Server game files' in page
    assert 'Import server save' in page
    assert 'Save to server' in page
    assert '<dialog' not in page and 'showModal' not in page
    assert requests.get(site+'/?ui=ultra',allow_redirects=False).status_code==303
    assert 'Ultra Low-end' in (ROOT/'pvz-portable.html').read_text()
    js=s.get(site+'/ultra/engine.js')
    assert js.status_code==200
    assert 'XMLHttpRequest' in js.text and 'window.Module' in js.text
    assert all(word not in js.text for word in ('fetch(', 'async function','=>', 'new Promise('))


def test_session_privacy_and_token_not_in_urls(site):
    assert requests.get(site+'/ultra/manifest.js').status_code==401
    assert requests.get(site+'/ultra/resource-file?f=main.pak').status_code==401
    assert requests.get(site+'/ultra/download-save').status_code==401
    s=requests.Session()
    fail=s.post(site+'/ultra/login',data={'token':'wrong'})
    assert 'Wrong server token' in fail.text
    success=s.post(site+'/ultra/login',data={'token':TOKEN})
    assert TOKEN not in success.url and TOKEN not in success.text
    cookie=s.cookies.get('pvz_ultra_sid')
    assert cookie and len(cookie)>35
    assert s.get(site+'/ultra/manifest.js').status_code==200


def test_choose_game_resources_without_browser_js(site):
    s,c=login(site)
    res=s.post(site+'/ultra/select-resource',data={'csrf':c,'choice':'tiny-resources.zip'})
    assert 'Selected game resources: tiny-resources.zip' in res.text
    manifest=s.get(site+'/ultra/manifest.js')
    assert 'main.pak' in manifest.text
    r=s.get(site+'/ultra/resource-file',params={'f':'main.pak'})
    assert r.content==b'pvz game data'
    assert s.get(site+'/ultra/resource-file',params={'f':'../../etc/passwd'}).status_code==404
    assert s.get(site+'/ultra/download-resource').content.startswith(b'PK')
    assert s.post(site+'/ultra/select-resource',data={'csrf':'bad','choice':'tiny-resources.zip'}).status_code==403


def test_recovery_save_picker_history_file_import_and_upload(site):
    # API creates the initial save; then test old-browser selection via HTML forms.
    h={'X-PvZ-Server-Token':TOKEN,'X-PvZ-Save-Key':KEY,'Content-Type':'application/zip'}
    v1=zipped({'userdata/users.dat':b'first'})
    v2=zipped({'userdata/users.dat':b'second'})
    assert requests.post(site+'/api/saves/manual',data=v1,headers=h).status_code==200
    assert requests.post(site+'/api/saves/manual',data=v2,headers=h).status_code==200
    s,c=login(site)
    reply=s.post(site+'/ultra/recovery',data={'csrf':c,'key':KEY})
    assert 'manual - current' in reply.text
    assert 'manual - history' in reply.text
    assert s.post(site+'/ultra/select-save',data={'csrf':c,'choice':'manual'}).status_code==200
    assert s.get(site+'/ultra/save-file',params={'f':'userdata/users.dat'}).content==b'second'
    assert s.get(site+'/ultra/download-save').content==v2
    rev=requests.get(site+'/api/saves/manual/history',headers=h).json()['history'][0]['revision']
    assert 'Selected save' in s.post(site+'/ultra/select-save',data={'csrf':c,'choice':'manual@'+rev}).text
    assert s.get(site+'/ultra/save-file',params={'f':'userdata/users.dat'}).content==b'first'
    # Old browser can upload ZIP via classic multipart form; no FileReader needed.
    third=zipped({'userdata/users.dat':b'third'})
    form={'csrf':c,'slot':'uploaded'}
    result=s.post(site+'/ultra/upload-save',data=form,files={'archive':('save.zip',third,'application/zip')})
    assert result.status_code==200
    assert 'uploaded - current' in result.text
    assert requests.get(site+'/api/saves/uploaded',headers=h).content==third
    # A completely different recovery key must never show these saves.
    other,oc=login(site)
    reply=other.post(site+'/ultra/recovery',data={'csrf':oc,'key':'c'*64})
    assert 'manual - current' not in reply.text
    assert other.get(site+'/ultra/download-save').status_code==404


def test_raw_save_commit_and_keep_old_history(site):
    s,c=login(site)
    s.post(site+'/ultra/recovery',data={'csrf':c,'key':KEY})
    r=s.post(site+'/ultra/put-file?path=userdata/users.dat',data=b'raw-browser-save',
             headers={'Content-Type':'application/octet-stream','X-PvZ-Ultra-CSRF':c})
    assert r.status_code==200
    assert s.post(site+'/ultra/put-file?path=../escape',data=b'x',
                  headers={'Content-Type':'application/octet-stream','X-PvZ-Ultra-CSRF':c}).status_code==400
    res=s.post(site+'/ultra/commit-save',data={'csrf':c,'slot':'manual'})
    assert res.status_code==200
    h={'X-PvZ-Server-Token':TOKEN,'X-PvZ-Save-Key':KEY}
    body=requests.get(site+'/api/saves/manual',headers=h).content
    with zipfile.ZipFile(io.BytesIO(body)) as z:
        assert z.read('userdata/users.dat')==b'raw-browser-save'
    assert requests.get(site+'/api/saves/manual/history',headers=h).json()['history']


def test_old_browser_base64_chunked_save_roundtrip_and_atomicity(site):
    import base64
    from urllib.parse import urljoin
    s, c = login(site)
    s.post(site+'/ultra/recovery', data={'csrf': c, 'key': KEY})
    api = {'X-PvZ-Server-Token':TOKEN, 'X-PvZ-Save-Key':KEY}
    src = bytes(range(256)) * 300  # >1 chunk, includes NUL and every byte value
    files = {'userdata/users.dat': b'username', 'userdata/game1_0.v4': src}
    h = {**api, 'Content-Type': 'application/zip'}
    before = zipped({'userdata/users.dat':b'previous-full-save', 'userdata/game1_0.v4':b'previous-progress'})
    assert requests.post(site+'/api/saves/chunked', data=before, headers=h).status_code == 200

    assert s.post(site+'/ultra/begin-save',data={'csrf':c}).status_code == 200
    # interrupted upload must leave existing ZIP untouched
    first = base64.b64encode(src[:48*1024]).decode('ascii')
    r=s.post(site+'/ultra/save-chunk', data={'csrf':c,'path':'userdata/game1_0.v4','offset':'0','data':first})
    assert r.status_code==200, r.text
    assert requests.get(site+'/api/saves/chunked',headers=api).content == before
    assert s.post(site+'/ultra/save-chunk', data={'csrf':c,'path':'userdata/game1_0.v4','offset':'0','data':first}).status_code==409
    assert s.post(site+'/ultra/save-chunk', data={'csrf':c,'path':'../bad','offset':'0','data':first}).status_code==400
    assert s.post(site+'/ultra/save-chunk', data={'csrf':'wrong','path':'userdata/users.dat','offset':'0','data':first}).status_code==403

    # starting a new transaction drops stale partials
    assert s.post(site+'/ultra/begin-save',data={'csrf':c}).status_code == 200
    for path, data in files.items():
        for off in range(0,len(data),48*1024):
            chunk=data[off:off+48*1024]
            r=s.post(site+'/ultra/save-chunk',data={'csrf':c,'path':path,'offset':str(off),
                                                     'data':base64.b64encode(chunk).decode('ascii')})
            assert r.status_code==200,(r.status_code,r.text)
    r=s.post(site+'/ultra/commit-save',data={'csrf':c,'slot':'chunked'})
    assert r.status_code==200, r.text
    body=requests.get(site+'/api/saves/chunked',headers=api).content
    with zipfile.ZipFile(io.BytesIO(body)) as z:
        assert {k:z.read(k) for k in files} == files
    assert requests.get(site+'/api/saves/chunked/history',headers=api).json()['history']
