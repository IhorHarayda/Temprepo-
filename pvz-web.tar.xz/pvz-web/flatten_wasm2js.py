#!/usr/bin/env python3
"""Flatten deeply nested labeled blocks in generated wasm2js JavaScript.

Named block exits become forward state-machine jumps. Compiled arithmetic and
memory initializers are preserved. This handles every long ladder, including
ladders introduced by a different minifier/build, and is safe to run repeatedly.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import re

_IDENTIFIER = r"[A-Za-z_$][\w$]*"
_LADDER = re.compile(r"(?<![\w$])" + _IDENTIFIER + r"\s*:\s*\{(?:\s*" + _IDENTIFIER + r"\s*:\s*\{)*")
_LABEL = re.compile(r"(" + _IDENTIFIER + r")\s*:\s*\{")
_OPAQUE = re.compile(
    r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|`(?:\\.|[^`\\])*`'
    r"|//[^\n]*|/\*[\s\S]*?\*/"
)
_JUMP = re.compile(r"\b(break|continue)(?:[ \t]+(" + _IDENTIFIER + r"))?(?=\s*(?:[;}]|$))")
_CONTROL = re.compile(r"(?<![\w$])(?:(" + _IDENTIFIER + r")\s*:\s*)?(for|while|switch|do)\s*[({]")


def _code_mask(source: str) -> str:
    # wasm2js emits no regex literals in its compiled body. Restrict inspection
    # to that body when Emscripten markers exist; its runtime glue may use them.
    start = source.find("// EMSCRIPTEN_START_ASM")
    end = source.find("// EMSCRIPTEN_END_ASM")
    if start >= 0 and end > start:
        body_start = source.find("\n", start) + 1
        source = " " * body_start + source[body_start:end] + " " * (len(source) - end)
    return _OPAQUE.sub(lambda m: " " * len(m.group()), source)


def _matching_delimiters(code: str) -> dict[int, int]:
    stack: list[tuple[str, int]] = []
    closes: dict[int, int] = {}
    for match in re.finditer(r"[{}()]", code):
        token = match.group()
        if token in "{(":
            stack.append((token, match.start()))
        else:
            if not stack or stack[-1][0] != ("{" if token == "}" else "("):
                raise ValueError("Unbalanced generated JavaScript delimiters")
            _, opening = stack.pop()
            closes[opening] = match.start()
    if stack:
        raise ValueError("Unclosed generated JavaScript delimiter")
    return closes


def _control_ranges(code: str, closes: dict[int, int]) -> list[tuple[int, int, str, str | None]]:
    ranges = []
    for match in _CONTROL.finditer(code):
        kind = match.group(2)
        opening = match.end() - 1
        if kind != "do":
            opening = closes[opening] + 1
            while opening < len(code) and code[opening].isspace():
                opening += 1
        # All generated loops/switches containing jumps use braced bodies.
        if opening < len(code) and code[opening] == "{":
            ranges.append((opening, closes[opening], kind, match.group(1)))
    return ranges


def _flatten(source: str, min_labels: int) -> tuple[str, list[tuple[int, int]]]:
    if min_labels < 2:
        raise ValueError("min_labels must be at least 2")
    statistics: list[tuple[int, int]] = []
    serial = 0
    while True:
        code = _code_mask(source)
        candidates = []
        for match in _LADDER.finditer(code):
            labels = list(_LABEL.finditer(code, match.start(), match.end()))
            if len(labels) >= min_labels:
                candidates.append((match, labels))
        if not candidates:
            return source, statistics
        closes = _matching_delimiters(code)
        controls = _control_ranges(code, closes)
        replacements = []
        previous_end = -1
        for match, labels in candidates:
            start = match.start()
            if start < previous_end:
                # Nested ladders are processed in the next pass, after their
                # containing ladder has been flattened.
                continue
            openings = [label.end() - 1 for label in labels]
            end = closes[openings[0]] + 1
            previous_end = end
            if re.search(r"\b(?:let|const|class|function)\b", code[match.end():end]):
                raise ValueError("Refusing a ladder with block-scoped declarations or nested functions")
            outer_jumps = {}
            for jump in _JUMP.finditer(code, match.end(), end):
                if jump.group(2):
                    continue
                # Introducing a dispatch loop must not capture a jump to an
                # enclosing loop/switch. Generated outer loops already have
                # labels; make that original target explicit when needed.
                enclosing = [
                    control for control in controls
                    if control[0] < jump.start() < control[1]
                    and (jump.group(1) == "break" or control[2] != "switch")
                ]
                target = max(enclosing, default=None, key=lambda item: item[0])
                if target is None or (target[0] < start and not target[3]):
                    raise ValueError("Unlabelled jump targets outside the ladder")
                if target[0] < start:
                    outer_jumps[jump.start()] = f"{jump.group(1)} {target[3]}"
            while True:
                serial += 1
                state = f"__pvz_flat_state_{serial}"
                loop = f"__pvz_flat_loop_{serial}"
                if state not in source and loop not in source:
                    break
            targets = {label.group(1): len(labels) - index for index, label in enumerate(labels)}
            if len(targets) != len(labels):
                raise ValueError("Duplicate labels in a generated ladder")
            segments = [(match.end(), closes[openings[-1]])]
            segments.extend(
                (closes[openings[index]] + 1, closes[openings[index - 1]])
                for index in range(len(openings) - 1, 0, -1)
            )
            # Remove only the label syntax, retaining all comments/spacing
            # between and within label headers.
            header = "".join(
                source[position] if code[position].isspace() else " "
                for position in range(start, match.end())
            )
            parts = [f"var {state}=0;{loop}:for(;;){{", header]
            jump_count = 0
            for index, (segment_start, segment_end) in enumerate(segments):
                cursor = segment_start
                body = []
                for jump in _JUMP.finditer(code, segment_start, segment_end):
                    if jump.start() in outer_jumps:
                        body.append(source[cursor:jump.start()])
                        body.append(outer_jumps[jump.start()])
                        cursor = jump.end()
                        continue
                    target = targets.get(jump.group(2))
                    if target is None:
                        continue
                    if jump.group(1) != "break":
                        raise ValueError("Cannot continue to a non-loop ladder label")
                    if target <= index:
                        raise ValueError("Jump to an already closed ladder label")
                    body.append(source[cursor:jump.start()])
                    body.append(f"{{{state}={target};continue {loop};}}")
                    cursor = jump.end()
                    terminator = cursor
                    while terminator < segment_end and code[terminator].isspace():
                        terminator += 1
                    if terminator < segment_end and code[terminator] == ";":
                        # The replacement is a compound statement: retain
                        # comments but remove its old semicolon so an unbraced
                        # `if (...) break label; else ...` remains valid.
                        body.append(source[cursor:terminator])
                        cursor = terminator + 1
                    jump_count += 1
                body.append(source[cursor:segment_end])
                parts.append(f"if({state}==={index}){{{state}={index + 1};" + "".join(body) + "}")
            parts.append(f"break {loop};}}")
            replacements.append((start, end, "".join(parts)))
            statistics.append((len(labels), jump_count))
        for start, end, replacement in reversed(replacements):
            source = source[:start] + replacement + source[end:]


def flatten_source(source: str, min_labels: int = 64) -> str:
    """Return generated JavaScript with all ladders of min_labels flattened."""
    return _flatten(source, min_labels)[0]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--min-labels", type=int, default=64)
    args = parser.parse_args()
    source = args.source.read_text(encoding="utf-8")
    transformed, statistics = _flatten(source, args.min_labels)
    args.destination.write_text(transformed, encoding="utf-8")
    print(
        "flattened ladders", len(statistics),
        "labels", sum(count for count, _ in statistics),
        "breaks", sum(count for _, count in statistics),
        "new bytes", len(transformed.encode("utf-8")),
        "old bytes", len(source.encode("utf-8")),
    )


if __name__ == "__main__":
    main()
