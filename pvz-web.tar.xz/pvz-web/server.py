#!/usr/bin/env python3
"""Minimal same-origin HTTP server for PvZ Portable WASM + opt-in server saves.

Run: python3 server.py --host 127.0.0.1 --port 8000
For public/LAN binding, set PVZ_SERVER_TOKEN to a strong secret and use HTTPS.
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import io
import json
import mimetypes
import os
import re
import secrets
import socket
import shutil
import sys
import time
import tempfile
import threading
import zipfile
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

# Keep helper modules sharing this exact server state when invoked as a script.
sys.modules.setdefault("server", sys.modules[__name__])
import ultra_legacy

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('PVZ_DATA_DIR', str(ROOT / 'server_data'))).resolve()
RESOURCES = DATA / 'resources'
SAVES = DATA / 'saves'
MAX_SAVE_BYTES = 16 * 1024 * 1024
MAX_UNCOMPRESSED_SAVE_BYTES = 32 * 1024 * 1024
MAX_SAVE_FILES = 300
MAX_SAVE_SLOTS = 20
HISTORY_LIMIT = 10  # Previous versions of EACH overwritten server save slot.
SLOT_RE = re.compile(r'[a-zA-Z0-9][a-zA-Z0-9_-]{0,39}\Z')
KEY_RE = re.compile(r'[0-9a-fA-F]{64}\Z')
REVISION_RE = re.compile(r'[0-9]{20}-[0-9a-f]{12}\Z')
STATIC_FILES = {
    '/': ('pvz-portable.html', 'text/html; charset=utf-8'),
    '/pvz-portable.html': ('pvz-portable.html', 'text/html; charset=utf-8'),
    '/pvz-portable.js': ('pvz-portable.js', 'application/javascript; charset=utf-8'),
    '/pvz-portable.wasm': ('pvz-portable.wasm', 'application/wasm'),
    '/pvz-portable-engine-fallback.js': ('pvz-portable-engine-fallback.js', 'application/javascript; charset=utf-8'),
    '/server-features.js': ('server-features.js', 'application/javascript; charset=utf-8'),
    '/jszip.min.js': ('jszip.min.js', 'application/javascript; charset=utf-8'),
    '/liquid-glass.css': ('liquid-glass.css', 'text/css; charset=utf-8'),
    '/low-end.css': ('low-end.css', 'text/css; charset=utf-8'),
}
SAVE_WRITE_LOCK = threading.Lock()


def valid_save_archive(body: bytes) -> tuple[bool, str]:
    """Check ZIP *before* committing it, limiting traversal, abuse and zip bombs."""
    try:
        with zipfile.ZipFile(io.BytesIO(body), 'r') as zf:
            if len(zf.infolist()) > MAX_SAVE_FILES:
                return False, 'Too many files in save ZIP.'
            size_sum = 0
            found_file = False
            for info in zf.infolist():
                name = info.filename
                pieces = name.replace('\\', '/').split('/')
                if (name.startswith('/') or '\\' in name or '\x00' in name or
                        any(p in ('.', '..') for p in pieces) or not pieces or
                        pieces[0] != 'userdata' or len(pieces) < 2):
                    return False, 'Save ZIP may contain only paths within userdata/.'
                if info.is_dir():
                    continue
                if (info.external_attr >> 16) & 0o170000 == 0o120000:
                    return False, 'Symlinks are not allowed in save ZIP.'
                found_file = True
                size_sum += info.file_size
                if size_sum > MAX_UNCOMPRESSED_SAVE_BYTES:
                    return False, 'Uncompressed save data exceeds the size limit.'
            if not found_file:
                return False, 'Save ZIP is empty.'
            if zf.testzip() is not None:
                return False, 'Save ZIP is corrupted.'
    except (zipfile.BadZipFile, OSError, ValueError, RuntimeError, EOFError):
        return False, 'Invalid save ZIP.'
    return True, ''


def is_game_resources_zip(path: Path) -> bool:
    try:
        if not path.is_file() or path.is_symlink() or path.suffix.lower() != '.zip':
            return False
        with zipfile.ZipFile(path, 'r') as zf:
            paths = [item.filename.replace('\\', '/').strip('/').lower() for item in zf.infolist() if not item.is_dir()]
            return any(s.endswith('/main.pak') or s == 'main.pak' for s in paths) and any(
                s.startswith('properties/') or '/properties/' in s for s in paths)
    except (zipfile.BadZipFile, OSError, ValueError):
        return False


def save_owner_folder(key: str) -> Path:
    # Do not store or expose the recovery secret as a filesystem pathname.
    return SAVES / hashlib.sha256(bytes.fromhex(key)).hexdigest()


def revision_dir(owner: Path, slot: str) -> Path:
    # Hidden subdirectories do not consume the user's 20 named save slots.
    return owner / '.history' / slot


def list_revisions(owner: Path, slot: str) -> list[Path]:
    folder = revision_dir(owner, slot)
    if not folder.is_dir() or folder.is_symlink():
        return []
    return sorted((path for path in folder.iterdir()
                   if path.is_file() and not path.is_symlink()
                   and path.suffix == '.zip' and REVISION_RE.fullmatch(path.stem)),
                  key=lambda path: path.name, reverse=True)


def snapshot_previous_save(owner: Path, slot: str, target: Path) -> None:
    """Preserve the previous full ZIP before replacing the live save.

    A failed snapshot aborts the new upload, leaving the old save untouched.
    Each history file is itself published using an atomic rename.
    """
    if not target.exists():
        return
    if not target.is_file() or target.is_symlink():
        raise OSError('Refusing to replace a non-regular server save.')
    directory = revision_dir(owner, slot)
    directory.parent.mkdir(mode=0o700, exist_ok=True)
    if directory.parent.is_symlink() or directory.is_symlink():
        raise OSError('Unsafe server save history path.')
    directory.mkdir(mode=0o700, exist_ok=True)
    revision_id = f'{time.time_ns():020d}-{secrets.token_hex(6)}'
    temp_path = None
    try:
        with target.open('rb') as source, tempfile.NamedTemporaryFile(
                mode='wb', prefix='.history-', suffix='.tmp', dir=directory,
                delete=False) as output:
            temp_path = Path(output.name)
            os.chmod(temp_path, 0o600)
            shutil.copyfileobj(source, output, length=256 * 1024)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temp_path, directory / f'{revision_id}.zip')
        temp_path = None
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)
    # Prune *after* a new history version is secure on disk.
    for old in list_revisions(owner, slot)[HISTORY_LIMIT:]:
        old.unlink()


class Handler(BaseHTTPRequestHandler):
    server_version = 'PvZPortableHTTP/1.0'

    def send_json(self, status: int, value: object) -> None:
        data = json.dumps(value, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        if self.command != 'HEAD':
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def json_error(self, status: int, message: str) -> None:
        self.send_json(status, {'error': message})

    def authorized(self) -> bool:
        secret: str = self.server.api_token  # type: ignore[attr-defined]
        if secret and not hmac.compare_digest(self.headers.get('X-PvZ-Server-Token', ''), secret):
            self.json_error(401, 'Server access token required or incorrect.')
            return False
        return True

    def get_owner(self) -> Path | None:
        key = self.headers.get('X-PvZ-Save-Key', '')
        if not KEY_RE.fullmatch(key):
            self.json_error(400, 'Missing or invalid server save recovery key.')
            return None
        return save_owner_folder(key)

    def send_file(self, path: Path, content_type: str, head: bool = False) -> None:
        try:
            with path.open('rb') as f:
                self.send_response(200)
                self.send_header('Content-Type', content_type)
                self.send_header('Content-Length', str(path.stat().st_size))
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.send_header('Cache-Control', 'no-store' if path.suffix == '.zip' else 'no-cache')
                self.end_headers()
                if not head:
                    while chunk := f.read(256 * 1024):
                        self.wfile.write(chunk)
        except (OSError, BrokenPipeError, ConnectionResetError) as exc:
            if isinstance(exc, (BrokenPipeError, ConnectionResetError)):
                return
            self.log_error('File error: %s', exc)

    def send_resource_zip(self, path: Path, head: bool = False) -> None:
        """Download a protected resource ZIP with optional HTTP byte ranges.

        Only /api/resources/<name> uses this method; other routes are untouched.
        This allows a slow LAN browser to retry one chunk rather than restart a
        30+ MiB ZIP. Standard RFC 7233 single byte ranges are sufficient here.
        """
        try:
            with path.open('rb') as f:
                stat = os.fstat(f.fileno())
                size = stat.st_size
                etag = f'"{size:x}-{stat.st_mtime_ns:x}"'
                range_value = self.headers.get('Range', '')
                if_range = self.headers.get('If-Range', '')
                if range_value and if_range and if_range != etag:
                    range_value = ''  # The file changed: only return a complete ZIP.
                start, end, status = 0, size - 1, 200
                if range_value:
                    match = re.fullmatch(r'bytes=(\d{1,20})-(\d{0,20})', range_value.strip())
                    if not match or size == 0:
                        self.send_response(416)
                        self.send_header('Content-Range', f'bytes */{size}')
                        self.send_header('Content-Length', '0')
                        self.send_header('Cache-Control', 'no-store')
                        self.send_header('X-Content-Type-Options', 'nosniff')
                        self.end_headers()
                        return
                    start = int(match.group(1))
                    end = int(match.group(2)) if match.group(2) else size - 1
                    if start >= size or end < start:
                        self.send_response(416)
                        self.send_header('Content-Range', f'bytes */{size}')
                        self.send_header('Content-Length', '0')
                        self.send_header('Cache-Control', 'no-store')
                        self.send_header('X-Content-Type-Options', 'nosniff')
                        self.end_headers()
                        return
                    end = min(end, size - 1)
                    status = 206
                count = max(0, end - start + 1)
                self.send_response(status)
                self.send_header('Content-Type', 'application/zip')
                self.send_header('Content-Length', str(count))
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('ETag', etag)
                self.send_header('Cache-Control', 'no-store')
                self.send_header('X-Content-Type-Options', 'nosniff')
                if status == 206:
                    self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
                self.end_headers()
                if head:
                    return
                f.seek(start)
                remaining = count
                while remaining:
                    chunk = f.read(min(256 * 1024, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)
        except (OSError, BrokenPipeError, ConnectionResetError) as exc:
            if isinstance(exc, (BrokenPipeError, ConnectionResetError)):
                return
            self.log_error('Resource ZIP download error: %s', exc)

    def handle_get(self, head: bool = False) -> None:
        url = urlsplit(self.path)
        path = url.path
        if path == '/' and parse_qs(url.query).get('ui') == ['ultra']:
            ultra_legacy.redirect(self, '/ultra/')
            return
        if ultra_legacy.get(self, head):
            return
        if path in STATIC_FILES:
            name, content_type = STATIC_FILES[path]
            target = ROOT / name
            if target.is_file():
                self.send_file(target, content_type, head)
            else:
                self.send_error(404)
            return
        if path == '/api/engine-status':
            self.send_json(200, {
                'wasm': (ROOT / 'pvz-portable.wasm').is_file() and (ROOT / 'pvz-portable.js').is_file(),
                'js': (ROOT / 'pvz-portable-engine-fallback.js').is_file(),
            })
            return
        if not path.startswith('/api/'):
            self.send_error(404)
            return
        if not self.authorized():
            return
        if path == '/api/resources':
            items = []
            if RESOURCES.is_dir():
                for f in sorted(RESOURCES.iterdir(), key=lambda p: p.name.lower()):
                    if is_game_resources_zip(f):
                        items.append({'id': f.name, 'name': f.stem, 'size': f.stat().st_size})
            self.send_json(200, {'resources': items})
            return
        if path.startswith('/api/resources/'):
            name = unquote(path.removeprefix('/api/resources/'))
            if not name or '/' in name or '\\' in name or name.startswith('.'):
                self.json_error(400, 'Invalid resource ID.')
                return
            target = RESOURCES / name
            if not is_game_resources_zip(target):
                self.json_error(404, 'Resource ZIP not found.')
                return
            self.send_resource_zip(target, head)
            return
        if path == '/api/saves':
            owner = self.get_owner()
            if owner is None:
                return
            items = []
            if owner.is_dir():
                for f in sorted(owner.glob('*.zip'), key=lambda p: p.name):
                    if not f.is_file() or f.is_symlink() or not SLOT_RE.fullmatch(f.stem):
                        continue
                    stat = f.stat()
                    items.append({'slot': f.stem, 'size': stat.st_size,
                                  'updated_at': datetime.fromtimestamp(stat.st_mtime, timezone.utc).isoformat(),
                                  'history_count': len(list_revisions(owner, f.stem))})
            self.send_json(200, {'saves': items})
            return
        if path.startswith('/api/saves/'):
            owner = self.get_owner()
            if owner is None:
                return
            suffix = unquote(path.removeprefix('/api/saves/'))
            segments = suffix.split('/')
            slot = segments[0]
            if not SLOT_RE.fullmatch(slot):
                self.json_error(400, 'Invalid save slot.')
                return
            target = owner / f'{slot}.zip'
            if not target.is_file() or target.is_symlink():
                self.json_error(404, 'Save not found.')
                return
            if len(segments) == 1:
                self.send_file(target, 'application/zip', head)
                return
            if len(segments) >= 2 and segments[1] == 'history':
                if len(segments) == 2:
                    revisions = list_revisions(owner, slot)
                    self.send_json(200, {'slot': slot, 'limit': HISTORY_LIMIT,
                                         'history': [{'revision': f.stem, 'size': f.stat().st_size,
                                                      'created_at': datetime.fromtimestamp(
                                                          f.stat().st_mtime, timezone.utc).isoformat()}
                                                     for f in revisions]})
                    return
                if len(segments) == 3 and REVISION_RE.fullmatch(segments[2]):
                    revision = revision_dir(owner, slot) / f'{segments[2]}.zip'
                    if not revision.is_file() or revision.is_symlink():
                        self.json_error(404, 'History version not found.')
                    else:
                        self.send_file(revision, 'application/zip', head)
                    return
            self.json_error(400, 'Invalid save history path.')
            return
        self.json_error(404, 'Not found.')

    def do_GET(self) -> None:
        self.handle_get()

    def do_HEAD(self) -> None:
        self.handle_get(head=True)

    def do_POST(self) -> None:
        if ultra_legacy.post(self):
            return
        path = urlsplit(self.path).path
        if not path.startswith('/api/saves/'):
            self.json_error(404, 'Not found.')
            return
        if not self.authorized():
            return
        owner = self.get_owner()
        if owner is None:
            return
        slot = unquote(path.removeprefix('/api/saves/'))
        if not SLOT_RE.fullmatch(slot):
            self.json_error(400, 'Save slot must be 1-40 ASCII letters, digits, _ or -.')
            return
        if self.headers.get('Content-Type', '').split(';', 1)[0].strip().lower() not in ('application/zip', 'application/octet-stream'):
            self.json_error(415, 'Only ZIP save uploads are supported.')
            return
        try:
            length = int(self.headers.get('Content-Length', '-1'))
        except ValueError:
            length = -1
        if length < 0:
            self.json_error(411, 'Content-Length required.')
            return
        if length == 0 or length > MAX_SAVE_BYTES:
            self.json_error(413, 'Save ZIP exceeds 16 MiB or is empty.')
            return
        body = self.rfile.read(length)
        if len(body) != length:
            self.json_error(400, 'Incomplete upload.')
            return
        okay, reason = valid_save_archive(body)
        if not okay:
            self.json_error(400, reason)
            return
        with SAVE_WRITE_LOCK:
            owner.mkdir(parents=True, exist_ok=True, mode=0o700)
            target = owner / f'{slot}.zip'
            if not (target.exists() or target.is_symlink()) and len(list(owner.glob('*.zip'))) >= MAX_SAVE_SLOTS:
                self.json_error(409, 'Maximum 20 server save slots per recovery key.')
                return
            temp_name = None
            try:
                with tempfile.NamedTemporaryFile(mode='wb', prefix='.save-', suffix='.tmp', dir=owner, delete=False) as f:
                    temp_name = f.name
                    os.chmod(temp_name, 0o600)
                    f.write(body)
                    f.flush()
                    os.fsync(f.fileno())
                # Only publish the new save after safely archiving the previous one.
                # If the history volume fills up, the known-good live save survives.
                snapshot_previous_save(owner, slot, target)
                os.replace(temp_name, target)
            except OSError as exc:
                self.log_error('Save write/history error: %s', exc)
                self.json_error(507, 'Could not safely write save history or new save; old save was preserved.')
                return
            finally:
                if temp_name and os.path.exists(temp_name):
                    os.unlink(temp_name)
        self.send_json(200, {'ok': True, 'slot': slot, 'bytes': len(body),
                             'history_count': len(list_revisions(owner, slot))})

    def do_DELETE(self) -> None:
        path = urlsplit(self.path).path
        if not path.startswith('/api/saves/'):
            self.json_error(404, 'Not found.')
            return
        if not self.authorized():
            return
        owner = self.get_owner()
        if owner is None:
            return
        slot = unquote(path.removeprefix('/api/saves/'))
        if not SLOT_RE.fullmatch(slot):
            self.json_error(400, 'Invalid save slot.')
            return
        with SAVE_WRITE_LOCK:
            target = owner / f'{slot}.zip'
            if not target.is_file() or target.is_symlink():
                self.json_error(404, 'Save not found.')
                return
            target.unlink(missing_ok=True)
            # Deleting an entire slot should also erase its private older versions.
            history = revision_dir(owner, slot)
            if history.is_dir() and not history.is_symlink():
                shutil.rmtree(history)
        self.send_json(200, {'ok': True, 'deleted': slot})



class IPv6ThreadingHTTPServer(ThreadingHTTPServer):
    """IPv6 listener; allow IPv4-mapped clients on :: when supported."""
    address_family = socket.AF_INET6

    def server_bind(self) -> None:
        if self.server_address[0] == '::':
            try:
                self.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
            except OSError:
                # Some systems enforce IPv6-only sockets.
                pass
        super().server_bind()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8000)
    args = parser.parse_args()
    secret = os.environ.get('PVZ_SERVER_TOKEN', '')
    if args.host not in ('localhost', '127.0.0.1', '::1') and len(secret) < 16:
        parser.error('PVZ_SERVER_TOKEN must be set (at least 16 chars) before binding beyond localhost; use HTTPS in production.')
    RESOURCES.mkdir(parents=True, exist_ok=True)
    SAVES.mkdir(parents=True, exist_ok=True)
    server_class = IPv6ThreadingHTTPServer if ':' in args.host else ThreadingHTTPServer
    server = server_class((args.host, args.port), Handler)
    server.api_token = secret  # type: ignore[attr-defined]
    url_host = f'[{args.host}]' if ':' in args.host else args.host
    print(f'PvZ Portable server: http://{url_host}:{server.server_port}/', flush=True)
    print(f'Server resource ZIPs: {RESOURCES}', flush=True)
    print(f'Private save ZIPs:    {SAVES}', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
