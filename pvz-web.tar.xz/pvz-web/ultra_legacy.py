"""Cookie-session, server-rendered Ultra Low-end UI for vintage browsers.
No JavaScript is needed for token entry, selectors or downloads.
The old-browser game bootstrap is isolated in ultra-engine.js.
"""
from __future__ import annotations

import hashlib
import base64
import binascii
import hmac
import html
import io
import os
import re
import secrets
import tempfile
import shutil
import threading
from email.parser import BytesParser
from email import policy
import time
import zipfile
from datetime import datetime, timezone
from http.cookies import SimpleCookie
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit

SESSION_LOCK = threading.RLock()
SESSIONS: dict[str, dict] = {}
SESSION_TTL = 2 * 60 * 60
COOKIE_NAME = 'pvz_ultra_sid'
MAX_BODY = 32 * 1024 * 1024


def h(value) -> str:
    return html.escape(str(value), quote=True)


def session_for(handler):
    cookie = SimpleCookie()
    try:
        cookie.load(handler.headers.get('Cookie', ''))
        sid = cookie[COOKIE_NAME].value if COOKIE_NAME in cookie else ''
    except Exception:
        sid = ''
    with SESSION_LOCK:
        s = SESSIONS.get(sid)
        if s and s['expires'] > time.time():
            s['expires'] = time.time() + SESSION_TTL
            return s
    return None


def fresh_session(handler):
    sid = secrets.token_urlsafe(32)
    item = {'sid': sid, 'csrf': secrets.token_hex(16), 'expires': time.time()+SESSION_TTL,
            'key': '', 'resource': '', 'save': '', 'revision': '', 'pending': {}}
    with SESSION_LOCK:
        for old, s in list(SESSIONS.items()):
            if s['expires'] < time.time():
                SESSIONS.pop(old, None)
        SESSIONS[sid] = item
    return item


def send(handler, code, body, content_type='text/html; charset=utf-8', cookie=None, head=False, disposition=None):
    if isinstance(body, str):
        body = body.encode('utf-8')
    handler.send_response(code)
    handler.send_header('Content-Type', content_type)
    handler.send_header('Content-Length', str(len(body)))
    handler.send_header('Cache-Control', 'no-store')
    handler.send_header('X-Content-Type-Options', 'nosniff')
    handler.send_header('X-Frame-Options', 'DENY')
    handler.send_header('Referrer-Policy', 'no-referrer')
    if cookie:
        suffix = '; Secure' if handler.headers.get('X-Forwarded-Proto','') == 'https' else ''
        handler.send_header('Set-Cookie', COOKIE_NAME + '=' + cookie + '; Path=/ultra; HttpOnly; SameSite=Lax; Max-Age=7200'+suffix)
    if disposition:
        handler.send_header('Content-Disposition', 'attachment; filename="' + disposition + '"')
    handler.end_headers()
    if not head:
        try:
            handler.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass


def redirect(handler, where='/ultra/', cookie=None):
    handler.send_response(303)
    handler.send_header('Location', where)
    handler.send_header('Content-Length', '0')
    handler.send_header('Cache-Control', 'no-store')
    if cookie:
        handler.send_header('Set-Cookie', COOKIE_NAME+'='+cookie+'; Path=/ultra; HttpOnly; SameSite=Lax; Max-Age=7200')
    handler.end_headers()


def fail(handler, code, msg):
    send(handler, code, '<!doctype html><html><head><meta charset="utf-8"><title>Ultra: error</title></head><body><h1>'+h(code)+'</h1><p>'+h(msg)+'</p><p><a href="/ultra/">Back</a></p></body></html>')


def form_body(handler, limit=4096):
    try:
        n = int(handler.headers.get('Content-Length', '-1'))
    except ValueError:
        n = -1
    if n < 0 or n > limit:
        return None
    if handler.headers.get('Content-Type','').split(';')[0].strip().lower() != 'application/x-www-form-urlencoded':
        return None
    data = handler.rfile.read(n).decode('utf-8', 'replace')
    return {k: v[0] for k,v in parse_qs(data, keep_blank_values=True, max_num_fields=8).items()}


def authorized(handler, session):
    return bool(session and (not handler.server.api_token or session.get('sid')))


def entries_for_resources(server):
    from server import RESOURCES, is_game_resources_zip
    if not RESOURCES.is_dir():
        return []
    return sorted([p for p in RESOURCES.iterdir() if is_game_resources_zip(p)], key=lambda p:p.name.lower())


def entries_for_save(session):
    from server import SAVES, save_owner_folder, list_revisions, SLOT_RE
    if not session or not session.get('key'):
        return []
    owner = save_owner_folder(session['key'])
    if not owner.is_dir():
        return []
    files=[]
    for p in sorted(owner.glob('*.zip')):
        if not p.is_file() or p.is_symlink() or not SLOT_RE.fullmatch(p.stem):
            continue
        files.append((p.stem, p, list_revisions(owner,p.stem)))
    return files


def resource_path(session):
    from server import RESOURCES, is_game_resources_zip
    if not session or not session.get('resource'):
        return None
    p=RESOURCES/session['resource']
    return p if is_game_resources_zip(p) else None


def save_path(session):
    from server import save_owner_folder, SLOT_RE, REVISION_RE, revision_dir
    if not session or not session.get('key'):
        return None
    slot=session.get('save','')
    if not SLOT_RE.fullmatch(slot):
        return None
    owner=save_owner_folder(session['key'])
    rev=session.get('revision','')
    if rev and REVISION_RE.fullmatch(rev):
        p=revision_dir(owner,slot)/(rev+'.zip')
    else:
        p=owner/(slot+'.zip')
    if p.is_file() and not p.is_symlink():
        return p
    return None


def zip_paths(path, kind):
    """Return safe normalized filenames and sizes, no archive traversal."""
    output=[]
    with zipfile.ZipFile(path) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            raw=info.filename.replace('\\','/')
            bits=raw.split('/')
            if any(v in ('', '.', '..') for v in bits) or raw.startswith('/'):
                continue
            if kind=='resource':
                if 'main.pak' in bits:
                    idx=bits.index('main.pak'); name='/'.join(bits[idx:])
                elif 'properties' in bits:
                    idx=bits.index('properties'); name='/'.join(bits[idx:])
                else:
                    continue
            else:
                if not raw.startswith('userdata/'):
                    continue
                name=raw
            output.append((name, raw, info.file_size))
    return output


def options_form(action, items, chosen, csrf, title, help_text, name='choice'):
    options=''.join('<option value="'+h(value)+'"'+(' selected' if chosen==value else '')+'>'+h(label)+'</option>' for value,label in items)
    if not options:
        return '<section><h2>'+h(title)+'</h2><p>'+h(help_text)+'</p><p>No files available.</p></section>'
    return ('<section><h2>'+h(title)+'</h2><p>'+h(help_text)+'</p>'
            '<form method="post" action="/ultra/'+h(action)+'">'
            '<input type="hidden" name="csrf" value="'+h(csrf)+'">'
            '<label><span>Choose file</span><select name="'+h(name)+'">'+options+'</select></label>'
            '<p><input type="submit" value="Select / Import"></p></form></section>')


def page(handler, session, message=''):
    logged = authorized(handler,session)
    csrf = session['csrf'] if session else ''
    top = ('<!DOCTYPE html><html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">'
           '<meta name="viewport" content="width=device-width,initial-scale=1">'
           '<title>PvZ Portable - Ultra Low-end</title>'
           '<style>body{font:16px Arial,Helvetica,sans-serif;background:#e9f0e5;color:#14281a;margin:0;padding:10px}'
           'main{max-width:760px;margin:auto}h1{font-size:26px;margin:14px 0}h2{font-size:19px}'
           'section{background:#fff;border:1px solid #8eaa94;margin:10px 0;padding:12px}'
           'label{display:block;margin:9px 0}input,select,button{font:16px Arial,sans-serif;padding:9px;max-width:100%}'
           'select,input[type=text],input[type=password]{width:100%;box-sizing:border-box}'
           'button,input[type=submit],.button{background:#17683d;color:white;border:1px solid #14502f;cursor:pointer;text-decoration:none}'
           'a{color:#034b31}canvas{display:block;max-width:100%;height:auto;background:#000}'
           '#ultra-game{display:none}#ultra-message{background:#fff9d2;padding:10px;border:1px solid #bda957;white-space:pre-wrap}'
           '.hint{font-size:13px;color:#3b5544}.status{background:#e5f6e9;padding:8px;margin:8px 0}'
           '.switch{display:block;margin-top:20px;padding:14px;border:1px solid #667d6b;background:#dde8dd}'
           '@media(max-width:440px){body{padding:5px}section{padding:10px}}</style></head><body><main>'
           '<h1>PvZ Portable - Ultra Low-end</h1>'
           '<p>Classic HTML interface - no Glass, popups, fetch or modern menus.</p>')
    if message:
        top += '<p id="ultra-server-notice">'+h(message)+'</p>'
    if not logged:
        top += ('<section><h2>Server token</h2><p>Enter the server token to access game resources and private saves.</p>'
                '<form method="post" action="/ultra/login">'
                '<label>PVZ_SERVER_TOKEN<input type="password" name="token" autocomplete="off"></label>'
                '<input type="submit" value="Connect"></form></section>')
    else:
        top += '<div class="status">Server access: connected. Selections are remembered in this browser for up to 2 hours.</div>'
        resources = entries_for_resources(handler.server)
        top += options_form('select-resource', [(p.name,p.stem+' ('+str(p.stat().st_size//1024)+' KB)') for p in resources],
                            session.get('resource',''),csrf,'1. Server game files','Select a server ZIP that contains main.pak and properties/.')
        if session.get('resource'):
            top += '<p class="hint">Selected game resources: '+h(session['resource'])+'</p>'
        key=session.get('key','')
        top += ('<section><h2>2. Recovery Key</h2><p>Enter your existing 64-character key to see your saves. '
                'Never share it publicly.</p><form method="post" action="/ultra/recovery">'
                '<input type="hidden" name="csrf" value="'+h(csrf)+'">'
                '<label>Recovery key<input type="text" name="key" maxlength="64" value="'+h(key)+'"></label>'
                '<p><input type="submit" value="Use recovery key"></p></form>'
                '<p class="hint">To create a new private save profile, use the standard site or enter a generated key you stored securely.</p></section>')
        saves = entries_for_save(session)
        choices=[('', '(No save - start fresh)')]
        for slot,p,rev in saves:
            choices.append((slot,slot+' - current ('+str(p.stat().st_size//1024)+' KB)'))
            for previous in rev:
                choices.append((slot+'@'+previous.stem, slot+' - history '+datetime.fromtimestamp(previous.stat().st_mtime,timezone.utc).strftime('%Y-%m-%d %H:%M UTC')))
        current = session.get('save','')+('@'+session['revision'] if session.get('revision') else '')
        top += options_form('select-save',choices,current,csrf,'3. Import server save',
                            'Choose a current save or an older version; import happens when you start the game.')
        if key and saves:
            top += '<p class="hint">Selected save: '+h(current or '(none)')+'; server originals are not modified on import.</p>'
        if key:
            top += ('<section><h2>Import a save ZIP from this device</h2>'
                    '<p>Classic file input works without JS and stores the ZIP in the private server slot. '
                    'The previous version remains in the 10-entry history.</p>'
                    '<form method="post" enctype="multipart/form-data" action="/ultra/upload-save">'
                    '<input type="hidden" name="csrf" value="'+h(csrf)+'">'
                    '<label>Local save ZIP <input type="file" name="archive" accept=".zip,application/zip" required></label>'
                    '<label>Server slot <input type="text" name="slot" value="imported" maxlength="40"></label>'
                    '<p><input type="submit" value="Upload save ZIP"></p></form></section>')
            if save_path(session):
                top += '<p><a href="/ultra/download-save">Download selected server save ZIP</a></p>'
        if resource_path(session):
            top += '<p><a href="/ultra/download-resource">Download selected game resource ZIP</a></p>'
        top += '<section><h2>4. Start game / controls</h2><p>Use <strong>JS Fallback</strong> (no native WASM).</p>'
        top += '<p><button type="button" id="ultra-start">Load selected files and start game</button></p>'
        top += ('<p><label>Server backup slot <input type="text" id="ultra-slot" value="manual" maxlength="40"></label>'
                '<button type="button" id="ultra-save" disabled>Save to server</button></p>'
                '<label><input type="checkbox" id="ultra-autobackup"> Auto server backup every 2 minutes (opt in)</label>'
                '<p class="hint">This mode does not promise local persistent saves. Use server backups. '
                'The older browser must support JavaScript typed arrays, Canvas/WebGL and the generated game engine.</p>'
                '<div id="ultra-message" class="status">Ready for selection.</div></section>'
                '<div id="ultra-game"><canvas width="800" height="600" id="canvas" tabindex="0"></canvas></div>')
        # Manifest data embedded as JS string literals, no modern syntax required.
        top += ('<script type="text/javascript">var PVZ_ULTRA_CSRF="'+h(csrf)+'";'
                'var PVZ_ULTRA_HAS_RESOURCE='+('true' if resource_path(session) else 'false')+';'
                'var PVZ_ULTRA_HAS_SAVE='+('true' if save_path(session) else 'false')+';'
                'var PVZ_ULTRA_HAS_KEY='+('true' if key else 'false')+';</script>'
                '<script type="text/javascript" src="/ultra/engine.js"></script>')
    top += ('<p class="switch"><label><input type="checkbox" checked onclick="window.location.href=\'/?ui=low&amp;backend=js\'"> <strong>Ultra Low-end: ON</strong></label><br>'
            '<a href="/?ui=low&amp;backend=js">Switch OFF - regular Low-end</a></p>'
            '<p class="hint">PS3: enable JavaScript and cookies in browser settings. '
            'HTTP forms work independently of game engine compatibility.</p></main></body></html>')
    send(handler,200,top)


def manifest_js(handler, session, head=False):
    import json
    p=resource_path(session)
    sp=save_path(session)
    rs=zip_paths(p,'resource') if p else []
    saves=zip_paths(sp,'save') if sp else []
    # JSON is valid as a classic ES3/ES5 JavaScript object literal.
    body=('window.PVZ_ULTRA_RESOURCE_FILES='+json.dumps([{'name':name,'path':raw,'size':size} for name,raw,size in rs],ensure_ascii=True)+';\n'
          'window.PVZ_ULTRA_SAVE_FILES='+json.dumps([{'name':name,'path':raw,'size':size} for name,raw,size in saves],ensure_ascii=True)+';\n')
    send(handler,200,body,'application/javascript; charset=utf-8',head=head)


def file_get(handler, session, kind, head=False):
    args=parse_qs(urlsplit(handler.path).query)
    raw=args.get('f',[''])[0]
    p=resource_path(session) if kind=='resource' else save_path(session)
    if not p:
        fail(handler,404,'No selected archive');return
    allowed = {raw_path:size for name,raw_path,size in zip_paths(p,kind)}
    if raw not in allowed:
        fail(handler,404,'File not part of selected archive');return
    try:
        with zipfile.ZipFile(p) as z:
            with z.open(raw) as reader:
                handler.send_response(200)
                handler.send_header('Content-Type','application/octet-stream')
                handler.send_header('Content-Length',str(allowed[raw]))
                handler.send_header('Cache-Control','no-store')
                handler.send_header('X-Content-Type-Options','nosniff')
                handler.end_headers()
                if not head:
                    while True:
                        part=reader.read(128*1024)
                        if not part:break
                        handler.wfile.write(part)
    except (zipfile.BadZipFile, OSError, BrokenPipeError, ConnectionResetError) as exc:
        handler.log_error('Ultra ZIP extraction: %s',exc)


def get(handler, head=False):
    from server import ROOT
    path=urlsplit(handler.path).path
    if path not in ('/ultra/','/ultra','/ultra/manifest.js','/ultra/engine.js','/ultra/resource-file','/ultra/save-file','/ultra/download-save','/ultra/download-resource'):
        return False
    if path=='/ultra/engine.js':
        handler.send_file(ROOT/'ultra-engine.js','application/javascript; charset=utf-8',head)
        return True
    s=session_for(handler)
    if path in ('/ultra','/ultra/'):
        if s is None and not handler.server.api_token:
            s=fresh_session(handler)
            # Set cookie, then render on second request.
            redirect(handler,'/ultra/',s['sid']);return True
        page(handler,s)
    elif not authorized(handler,s):
        fail(handler,401,'Connect first using /ultra/');return True
    elif path=='/ultra/manifest.js':
        manifest_js(handler,s,head)
    elif path in ('/ultra/resource-file','/ultra/save-file'):
        file_get(handler,s,'resource' if path.endswith('resource-file') else 'save',head)
    elif path in ('/ultra/download-save','/ultra/download-resource'):
        target=save_path(s) if path.endswith('save') else resource_path(s)
        if not target:
            fail(handler,404,'Nothing selected');return True
        # Keep the existing server ZIP intact, never expose the underlying private path.
        with target.open('rb') as f:
            handler.send_response(200)
            handler.send_header('Content-Type','application/zip')
            handler.send_header('Content-Disposition','attachment; filename="'+('pvz-save.zip' if path.endswith('save') else 'pvz-resources.zip')+'"')
            handler.send_header('Content-Length',str(target.stat().st_size))
            handler.send_header('Cache-Control','no-store')
            handler.end_headers()
            if not head:
                try:
                    shutil.copyfileobj(f,handler.wfile,length=256*1024)
                except (BrokenPipeError,ConnectionResetError):pass

    return True


def save_zip_form(handler, session):
    """Native multipart/form-data upload for browsers without FileReader.

    This is an explicit save-to-server action, not an automatic upload.
    """
    from server import (MAX_SAVE_BYTES, MAX_SAVE_SLOTS, SAVE_WRITE_LOCK, SLOT_RE,
                        save_owner_folder, snapshot_previous_save, valid_save_archive)
    if not session.get('key'):
        fail(handler,400,'Enter a Recovery Key first');return
    ctype=handler.headers.get('Content-Type','')
    if not ctype.lower().startswith('multipart/form-data;'):
        fail(handler,415,'Expected a browser file-upload form');return
    try:
        n=int(handler.headers.get('Content-Length','-1'))
    except ValueError:
        n=-1
    if n < 1 or n > MAX_SAVE_BYTES+8192:
        fail(handler,413,'Upload exceeds limit');return
    body=handler.rfile.read(n)
    if len(body)!=n:
        fail(handler,400,'Incomplete upload');return
    try:
        packet=BytesParser(policy=policy.default).parsebytes(
            b'MIME-Version: 1.0\r\nContent-Type: '+ctype.encode('ascii')+b'\r\n\r\n'+body)
        parts={}
        for part in packet.iter_parts():
            name=part.get_param('name',header='content-disposition')
            if name in ('csrf','slot','archive'):
                parts[name]=part.get_payload(decode=True)
        csrf=parts.get('csrf',b'').decode('utf-8','replace')
        slot=parts.get('slot',b'').decode('utf-8','replace')
        archive=parts.get('archive',b'')
    except (ValueError,TypeError,UnicodeError):
        fail(handler,400,'Invalid multipart form');return
    if not hmac.compare_digest(csrf,session['csrf']):
        fail(handler,403,'Invalid form token');return
    if not SLOT_RE.fullmatch(slot):
        fail(handler,400,'Invalid server save slot');return
    if not archive or len(archive)>MAX_SAVE_BYTES:
        fail(handler,413,'Invalid save size');return
    okay,reason=valid_save_archive(archive)
    if not okay:
        fail(handler,400,reason);return
    owner=save_owner_folder(session['key'])
    with SAVE_WRITE_LOCK:
        owner.mkdir(parents=True,exist_ok=True,mode=0o700)
        target=owner/(slot+'.zip')
        if not target.exists() and len(list(owner.glob('*.zip'))) >= MAX_SAVE_SLOTS:
            fail(handler,409,'Too many save slots');return
        tmp=None
        try:
            with tempfile.NamedTemporaryFile('wb',dir=owner,prefix='.ultra-upload-',delete=False) as f:
                tmp=f.name;os.chmod(tmp,0o600)
                f.write(archive);f.flush();os.fsync(f.fileno())
            snapshot_previous_save(owner,slot,target)
            os.replace(tmp,target);tmp=None
        except OSError:
            fail(handler,507,'Save write failed; old save was preserved');return
        finally:
            if tmp and os.path.exists(tmp):os.unlink(tmp)
    session['save']=slot;session['revision']=''
    redirect(handler)



def begin_save(handler, session, fields):
    if not session.get('key'):
        fail(handler,400,'Enter a Recovery Key before saving');return
    with SESSION_LOCK:
        session['pending'].clear()
    send(handler,200,'OK','text/plain; charset=utf-8')


def save_chunk(handler, session):
    """ES5-safe uploads: small base64 chunks in ordinary URL-encoded POSTs.

    Require exact sequential offsets. Only /ultra/commit-save can publish the
    assembled files, so incomplete uploads never touch existing save slots.
    """
    from server import MAX_SAVE_FILES, MAX_UNCOMPRESSED_SAVE_BYTES
    if not session.get('key'):
        fail(handler,400,'Recovery Key missing');return
    fields=form_body(handler,limit=100_000)
    if fields is None or not hmac.compare_digest(fields.get('csrf',''),session['csrf']):
        fail(handler,403,'Invalid form or CSRF token');return
    name=fields.get('path','')
    if (not name.startswith('userdata/') or '\\' in name or '\x00' in name or
            len(name)>250 or any(x in ('','.','..') for x in name.split('/'))):
        fail(handler,400,'Invalid save file path');return
    try:
        offset=int(fields.get('offset','-1'))
        chunk=base64.b64decode(fields.get('data',''),validate=True)
    except (ValueError,binascii.Error):
        fail(handler,400,'Invalid save chunk');return
    if (offset<0 or len(chunk)>48*1024 or
            (not chunk and not (fields.get('empty')=='1' and offset==0))):
        fail(handler,413,'Invalid chunk size or offset');return
    with SESSION_LOCK:
        pending=session['pending']
        if name not in pending and len(pending)>=MAX_SAVE_FILES:
            fail(handler,413,'Too many save files');return
        current=pending.get(name,b'')
        if offset!=len(current):
            fail(handler,409,'Wrong chunk offset, expected '+str(len(current)));return
        if sum(len(x) for x in pending.values())+len(chunk)>MAX_UNCOMPRESSED_SAVE_BYTES:
            fail(handler,413,'Save contents too large');return
        if name not in pending:
            pending[name]=bytearray()
        elif not isinstance(pending[name],bytearray):
            pending[name]=bytearray(current)
        pending[name].extend(chunk)
    send(handler,200,'OK','text/plain; charset=utf-8')


def save_pending_file(handler, session):
    args=parse_qs(urlsplit(handler.path).query)
    name=args.get('path',[''])[0]
    if not name.startswith('userdata/') or '\\' in name or '\x00' in name or len(name)>250 or any(x in ('','.','..') for x in name.split('/')):
        fail(handler,400,'Invalid save file path');return
    if not session.get('key'):
        fail(handler,400,'Recovery Key missing');return
    try:
        length=int(handler.headers.get('Content-Length','-1'))
    except ValueError:
        length=-1
    if length<0 or length>16*1024*1024:
        fail(handler,413,'File too large');return
    csrf=handler.headers.get('X-PvZ-Ultra-CSRF','')
    if not hmac.compare_digest(csrf,session['csrf']):
        fail(handler,403,'CSRF check failed');return
    if sum(len(x) for x in session['pending'].values())+length > 32*1024*1024:
        fail(handler,413,'Save contents too large');return
    data=handler.rfile.read(length)
    if len(data)!=length:
        fail(handler,400,'Incomplete upload');return
    with SESSION_LOCK:
        if len(session['pending'])>=300 and name not in session['pending']:
            fail(handler,413,'Too many save files');return
        session['pending'][name]=data
    send(handler,200,'OK','text/plain; charset=utf-8')


def save_commit(handler, session, fields):
    from server import (SAVE_WRITE_LOCK, MAX_SAVE_BYTES, MAX_SAVE_SLOTS, SLOT_RE,
                        list_revisions, save_owner_folder, snapshot_previous_save, valid_save_archive)
    slot=fields.get('slot','manual')
    if not SLOT_RE.fullmatch(slot):
        fail(handler,400,'Invalid save slot');return
    if not session.get('key') or not session['pending']:
        fail(handler,400,'No recovery key or pending files');return
    mem=io.BytesIO()
    with zipfile.ZipFile(mem,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,data in sorted(session['pending'].items()):
            z.writestr(name,data)
    body=mem.getvalue()
    if len(body)>MAX_SAVE_BYTES or not valid_save_archive(body)[0]:
        fail(handler,413,'Invalid or oversized save');return
    owner=save_owner_folder(session['key'])
    with SAVE_WRITE_LOCK:
        owner.mkdir(parents=True,exist_ok=True,mode=0o700)
        target=owner/(slot+'.zip')
        if not target.exists() and len(list(owner.glob('*.zip'))) >= MAX_SAVE_SLOTS:
            fail(handler,409,'Too many slots');return
        temp=None
        try:
            with tempfile.NamedTemporaryFile('wb',dir=owner,prefix='.ultra-',delete=False) as f:
                temp=f.name
                os.chmod(temp,0o600)
                f.write(body);f.flush();os.fsync(f.fileno())
            snapshot_previous_save(owner,slot,target)
            os.replace(temp,target);temp=None
        except OSError as e:
            handler.log_error('Ultra save write: %s',e)
            fail(handler,507,'Could not safely write save; old copy unchanged');return
        finally:
            if temp and os.path.exists(temp):os.unlink(temp)
        session['pending'].clear()
    send(handler,200,'OK','text/plain; charset=utf-8')


def post(handler):
    from server import KEY_RE, SLOT_RE, REVISION_RE, save_owner_folder, revision_dir
    path=urlsplit(handler.path).path
    if path not in ('/ultra/login','/ultra/recovery','/ultra/select-resource','/ultra/select-save',
                    '/ultra/put-file','/ultra/commit-save','/ultra/upload-save',
                    '/ultra/begin-save','/ultra/save-chunk'):
        return False
    if path=='/ultra/login':
        fields=form_body(handler)
        if fields is None:
            fail(handler,400,'Invalid login form');return True
        expected=handler.server.api_token
        if expected and not hmac.compare_digest(fields.get('token',''),expected):
            page(handler,None,'Wrong server token.');return True
        s=fresh_session(handler)
        redirect(handler,'/ultra/',s['sid'])
        return True
    s=session_for(handler)
    if not authorized(handler,s):
        fail(handler,401,'Login first');return True
    if path=='/ultra/put-file':
        save_pending_file(handler,s);return True
    if path=='/ultra/save-chunk':
        save_chunk(handler,s);return True
    if path=='/ultra/upload-save':
        save_zip_form(handler,s);return True
    fields=form_body(handler)
    if fields is None or not hmac.compare_digest(fields.get('csrf',''),s['csrf']):
        fail(handler,403,'Invalid form or CSRF token');return True
    if path=='/ultra/recovery':
        key=fields.get('key','').strip().lower()
        if not KEY_RE.fullmatch(key):
            page(handler,s,'Recovery Key must contain exactly 64 hexadecimal characters.');return True
        s['key']=key;s['save']='';s['revision']='';s['pending'].clear()
    elif path=='/ultra/select-resource':
        choice=fields.get('choice','')
        if choice not in [p.name for p in entries_for_resources(handler.server)]:
            fail(handler,400,'Invalid game resources');return True
        s['resource']=choice
    elif path=='/ultra/select-save':
        choice=fields.get('choice','')
        slot,sep,rev=choice.partition('@')
        if choice and (not SLOT_RE.fullmatch(slot) or (sep and not REVISION_RE.fullmatch(rev))):
            fail(handler,400,'Invalid save');return True
        if not s.get('key'):
            fail(handler,400,'Enter recovery key first');return True
        s['save']=slot;s['revision']=rev
        if choice and save_path(s) is None:
            s['save']='';s['revision']=''
            fail(handler,404,'Save not found');return True
    elif path=='/ultra/begin-save':
        begin_save(handler,s,fields);return True
    elif path=='/ultra/commit-save':
        save_commit(handler,s,fields);return True
    redirect(handler)
    return True
