#!/usr/bin/env python3
"""Cache an online cartoon-garden picture directly into liquid-glass.css.
No new HTTP paths, server-side changes, or external Python packages required.
"""
import argparse
import base64
from pathlib import Path
from urllib.request import Request, urlopen

URL = "https://cdn.pixabay.com/photo/2017/10/08/08/44/nature-2829157_1280.png"
PREFIX = "--garden-image:url("

def main():
    parser = argparse.ArgumentParser(description="Save Pixabay garden background inside Liquid Glass CSS")
    parser.add_argument("--file", help="Image file downloaded manually from the source (instead of fetching online)")
    args = parser.parse_args()
    if args.file:
        data = Path(args.file).read_bytes()
    else:
        req = Request(URL, headers={"User-Agent": "Mozilla/5.0 PvZ-Portable-background-cache/1.0"})
        with urlopen(req, timeout=30) as response:
            data = response.read(12 * 1024 * 1024 + 1)
    if len(data) > 12*1024*1024 or len(data) < 1024:
        raise SystemExit("Unexpected image size; not changing the CSS")
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        mime = "image/png"
    elif data.startswith(b"\xff\xd8\xff"):
        mime = "image/jpeg"
    elif data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        mime = "image/webp"
    else:
        raise SystemExit("Unsupported/non-image response; not changing the CSS")
    path = Path(__file__).resolve().parent / "liquid-glass.css"
    css = path.read_text(encoding="utf-8")
    pos = css.find(PREFIX)
    if pos < 0:
        raise SystemExit("CSS lacks --garden-image; not changing it")
    end = css.find('\");', pos)
    if end < 0:
        raise SystemExit("CSS declaration is malformed")
    uri = "data:" + mime + ";base64," + base64.b64encode(data).decode("ascii")
    css = css[:pos] + PREFIX + "\"" + uri + "\");" + css[end+3:]
    backup = path.with_suffix(".css.bak")
    if not backup.exists():
        backup.write_bytes(path.read_bytes())
    path.write_text(css, encoding="utf-8")
    print(f"OK: embedded {len(data)} bytes into {path.name}. Backup: {backup.name}")

if __name__ == "__main__":
    main()
