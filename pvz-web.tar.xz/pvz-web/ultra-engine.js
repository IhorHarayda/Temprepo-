/* PvZ Portable Ultra Low-end client. ES5 syntax; no fetch, Promise, popup or JSZip.
 * Game engine itself is a separate Emscripten build and may need newer browser features.
 */
(function () {
  var engineReady = false, engineRequested = false, loading = false, gameStarted = false;
  var gameFiles = [], saveFiles = [];
  var $ = function (id) { return document.getElementById(id); };
  var status = function (message) {
    var el = $('ultra-message');
    if (el) { if (typeof el.textContent !== 'undefined') el.textContent = message;
              else el.innerText = message; }
  };
  function on(element, type, handler) {
    if (!element) return;
    if (element.addEventListener) element.addEventListener(type,handler,false);
    else if (element.attachEvent) element.attachEvent('on'+type,handler);
  }
  function errorText(e) { return e && (e.message || e.description) || String(e); }
  function request(url, method, payload, type, cb, csrf) {
    var xhr;
    try { xhr = new XMLHttpRequest(); } catch (e) { cb('This browser does not support XMLHttpRequest.'); return; }
    try {
      xhr.open(method, url, true);
      if (type === 'binary') {
        try { xhr.responseType = 'arraybuffer'; } catch (e) {}
        if (typeof xhr.overrideMimeType === 'function') {
          try { xhr.overrideMimeType('text/plain; charset=x-user-defined'); } catch (e) {}
        }
      } else if (type === 'post') {
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      } else if (type === 'bytes') {
        xhr.setRequestHeader('Content-Type', 'application/octet-stream');
        xhr.setRequestHeader('X-PvZ-Ultra-CSRF', csrf);
      }
      xhr.onreadystatechange = function () {
        if (xhr.readyState !== 4) return;
        if (xhr.status < 200 || xhr.status >= 300) {
          cb('HTTP '+xhr.status+' while loading '+url); return;
        }
        if (type === 'binary') {
          try {
            if (xhr.response && xhr.response.byteLength !== undefined) {
              cb(null,new Uint8Array(xhr.response));return;
            }
            // Old XHR fallback (x-user-defined) when responseType=arraybuffer is unsupported.
            var str=xhr.responseText || '', data=new Uint8Array(str.length), i;
            for (i=0;i<str.length;i++) data[i]=str.charCodeAt(i)&255;
            cb(null,data);return;
          } catch (e) { cb('Binary XHR failed: '+errorText(e));return; }
        }
        cb(null,xhr.responseText || '');
      };
      xhr.send(payload || null);
    } catch (e) { cb(errorText(e)); }
  }
  function ensureFolder(path) {
    var parts=path.split('/'), folder='',i;
    for (i=0;i<parts.length-1;i++) {
      if (!parts[i]) continue;
      folder+='/'+parts[i];
      try { Module.FS.mkdir(folder); }
      catch(e) { /* Already exists; writeFile will report real failures. */ }
    }
  }
  function loadFiles(items,type,index,done) {
    if (index>=items.length) { done();return; }
    var item=items[index], path='/'+item.name;
    status('Downloading '+type+' '+(index+1)+'/'+items.length+': '+item.name+' ('+(item.size/1048576).toFixed(1)+' MiB)');
    request('/ultra/'+(type==='resources'?'resource-file':'save-file')+'?f='+encodeURIComponent(item.path),
      'GET',null,'binary',function(err,data) {
      if (err) { done(err);return; }
      try {
        if (type==='save') path='/saves/'+item.name;
        ensureFolder(path);
        Module.FS.writeFile(path,data);
      } catch(e) { done('Filesystem write: '+errorText(e));return; }
      setTimeout(function(){loadFiles(items,type,index+1,done);},1);
    });
  }
  function startGame() {
    if (loading || gameStarted) return;
    if (!window.PVZ_ULTRA_HAS_RESOURCE) {status('Select server game resources first using the form above.');return;}
    if (!engineReady) {
      if (!engineRequested) {
        engineRequested=true;
        status('Starting JS engine. Older browsers may not support this Emscripten build...');
        inject('/pvz-portable-engine-fallback.js',function(err) {
          if(err){status(err);return;}
          if(engineReady)startGame();
          else if(lastError)status('JS engine failed: '+lastError);
          else status('Engine loaded; awaiting initialization.');
        });
      } else status(lastError ? 'Engine error: '+lastError : 'Engine is still initializing...');
      return;
    }
    if (!Module || !Module.FS || typeof Module.callMain!=='function') {
      status('Emscripten runtime did not provide Module.FS and Module.callMain.');return;
    }
    if (typeof Uint8Array === 'undefined') { status('Typed arrays are unavailable. Cannot run this engine on this browser.');return; }
    loading = true;
    var btn=$('ultra-start');if(btn)btn.disabled=true;
    loadFiles(gameFiles,'resources',0,function(err) {
      if (err) {loading=false;if(btn)btn.disabled=false;status(err);return;}
      function restore() {
        loadFiles(saveFiles,'save',0,function(err2) {
          if (err2) {loading=false;if(btn)btn.disabled=false;status(err2);return;}
          status('Starting PvZ JavaScript backend...');
          $('ultra-game').style.display='block';
          try {
            gameStarted=true;
            if($('ultra-save'))$('ultra-save').disabled=false;
            if($('canvas').focus)$('canvas').focus();
            Module.callMain([]);
            loading=false; // Game is running; allow manual and opt-in server backups.
            status('Game started. Server backup is manual unless opted in.');
          } catch(e) {
            loading=false;gameStarted=false;if(btn)btn.disabled=false;
            status('Game start error: '+errorText(e));
          }
        });
      }
      try { Module.FS.mkdir('/saves'); } catch(e) {}
      // If IDBFS exists, first load the browser's old saves; *then* overwrite
      // them with the user's selected server backup.
      try {
        if (Module.FS.filesystems && Module.FS.filesystems.IDBFS && Module.FS.mount && Module.FS.syncfs) {
          Module.FS.mount(Module.FS.filesystems.IDBFS, {}, '/saves');
          Module.FS.syncfs(true,function(e){ if(e)status('Local IDBFS unavailable; server saves will still import.');restore(); });
        } else restore();
      } catch(e) {restore();}
    });
  }
  function collect(dir, out) {
    var files,i,p,st;
    try {files=Module.FS.readdir(dir);}catch(e){return;}
    for(i=0;i<files.length;i++) {
      if(files[i]==='.'||files[i]==='..')continue;
      p=dir+'/'+files[i];
      try {
        st=Module.FS.stat(p);
        if(Module.FS.isDir(st.mode))collect(p,out);
        else if(p.indexOf('/saves/userdata/')===0)out.push(p);
      } catch(e){}
    }
  }
  // Old WebKit does not reliably support XMLHttpRequest.send(Uint8Array).
  // Use small, base64-encoded HTML form posts instead. This also avoids
  // requiring a custom XHR header that some older browser builds reject.
  function base64Chunk(data, begin, end) {
    var alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var parts=[], block='', i, a, b, c, triple;
    for (i=begin;i<end;i+=3) {
      a=data[i]; b=i+1<end?data[i+1]:0; c=i+2<end?data[i+2]:0;
      triple=(a<<16)|(b<<8)|c;
      block+=alphabet.charAt((triple>>18)&63)+alphabet.charAt((triple>>12)&63)
            +(i+1<end?alphabet.charAt((triple>>6)&63):'=')
            +(i+2<end?alphabet.charAt(triple&63):'=');
      if (block.length>=4096) {parts.push(block);block='';}
    }
    parts.push(block);
    return parts.join('');
  }
  function backUp() {
    if (!gameStarted || loading) return;
    if (!PVZ_ULTRA_HAS_KEY) {
      status('Enter a Recovery Key in section 2 before saving to the server.');return;
    }
    var paths=[];collect('/saves/userdata',paths);
    if (!paths.length) {status('No saves found in /saves/userdata yet. Play and save first.');return;}
    paths.sort();
    var slot=$('ultra-slot').value || 'manual';
    if(!/^[A-Za-z0-9][A-Za-z0-9_-]{0,39}$/.test(slot)){status('Invalid slot name.');return;}
    loading=true;
    // Begin a clean transaction. Partial failed uploads never replace the
    // existing server ZIP, and old incomplete pending files cannot leak in.
    request('/ultra/begin-save','POST','csrf='+encodeURIComponent(PVZ_ULTRA_CSRF),'post',function(beginError){
      if(beginError){loading=false;status('Backup preparation failed: '+beginError);return;}
      function nextFile(index) {
        if (index>=paths.length) {
          status('Committing '+paths.length+' save files to server...');
          request('/ultra/commit-save','POST','csrf='+encodeURIComponent(PVZ_ULTRA_CSRF)+'&slot='+encodeURIComponent(slot),'post',function(err){
            loading=false;
            status(err ? 'Backup commit failed: '+err : 'Server backup complete: '+slot+' ('+paths.length+' files). Previous version is in History.');
          });return;
        }
        var path=paths[index], bytes;
        try {bytes=Module.FS.readFile(path);} catch(e) {
          loading=false;status('Cannot read '+path+': '+errorText(e));return;
        }
        if (!bytes || typeof bytes.length!=='number') {
          loading=false;status('Cannot read save bytes from '+path);return;
        }
        var name=path.substring(7), size=bytes.length, offset=0, CHUNK=48*1024;
        function nextChunk() {
          var end=Math.min(offset+CHUNK,size), data=base64Chunk(bytes,offset,end);
          status('Uploading save '+(index+1)+'/'+paths.length+': '+name+' ('+end+'/'+size+' bytes)');
          request('/ultra/save-chunk','POST',
            'csrf='+encodeURIComponent(PVZ_ULTRA_CSRF)+
            '&path='+encodeURIComponent(name)+
            '&offset='+offset+
            '&data='+encodeURIComponent(data)+(size===0?'&empty=1':''),
            'post',function(err){
              if (err){loading=false;status('Upload failed at '+name+' byte '+offset+': '+err);return;}
              if(end===size) {bytes=null;nextFile(index+1);return;}
              offset=end;
              setTimeout(nextChunk,0);
            });
        }
        nextChunk();
      }
      nextFile(0);
    });
  }

  var lastError = null;
  var originalError = window.onerror;
  window.onerror = function(msg,url,line) {
    lastError = String(msg)+' @ '+String(url).split('/').pop()+':'+line;
    if (!engineReady) status('Engine parse/evaluate error: '+lastError+'. Try another device; this browser may be too old.');
    if(typeof originalError==='function')return originalError.apply(this,arguments);
    return false;
  };
  window.Module = {
    canvas: $('canvas'),
    noInitialRun: true,
    onRuntimeInitialized: function () {
      engineReady=true;
      status('JS fallback runtime ready. Select resources and press Start.');
      if (engineRequested && !loading && !gameStarted) setTimeout(startGame, 0);
    },
    onAbort: function (reason) {status('Engine abort: '+String(reason));},
    print: function (str) { if(window.console&&console.log)console.log(str); },
    printErr: function (str) { if(window.console&&console.warn)console.warn(str); }
  };
  on($('ultra-start'),'click',startGame);
  on($('ultra-save'),'click',backUp);
  setInterval(function(){ if (gameStarted && $('ultra-autobackup') && $('ultra-autobackup').checked) backUp(); },120000);
  // First load a tiny same-origin manifest (classic script). Only then load
  // the Emscripten JS runtime; the HTML/form UI still works if either fails.
  function inject(src,done) {
    var el=document.createElement('script');el.type='text/javascript';el.src=src;
    el.onload=function(){done(null);};
    el.onerror=function(){done('Cannot load '+src);};
    var head=document.getElementsByTagName('head')[0]||document.body;
    head.appendChild(el);
  }
  status('Loading server manifest...');
  inject('/ultra/manifest.js',function(err){
    if(err){status(err);return;}
    gameFiles=window.PVZ_ULTRA_RESOURCE_FILES||[];
    saveFiles=window.PVZ_ULTRA_SAVE_FILES||[];
    status('Ready: '+gameFiles.length+' resource files, '+saveFiles.length+' save files. Press Start to load the JS engine.');
  });
}());
