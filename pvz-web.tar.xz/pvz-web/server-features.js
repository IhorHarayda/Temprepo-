/* Optional, same-origin server features for PvZ Portable. Local IDBFS stays the default. */
(() => {
  'use strict';

  const $ = id => document.getElementById(id);
  const saveKeyStorage = 'pvz-portable-server-save-recovery-key-v1';
  const apiTokenStorage = 'pvz-portable-server-token-session-v1';
  const autoBackupEveryMs = 2 * 60 * 1000;
  const maxDownloadBytes = 16 * 1024 * 1024;
  const saveStatus = $('server-save-status');
  let fallbackSaveKey = null;
  let fallbackApiToken = '';
  let serverUploadInProgress = false;
  let autoBackupTimer = null;
  let pickerMode = null;
  let selectedItems = [];

  // TV Bro and some Android TV WebViews block window.prompt/confirm/alert.
  // Use ordinary DOM controls instead. No new window, native popup or heavy CSS.
  const tvDialogStyles = `
    .pvz-tv-overlay{position:fixed;inset:0;z-index:2147483647;display:flex;
      align-items:center;justify-content:center;padding:16px;background:rgba(0,0,0,.86);
      font:16px/1.45 system-ui,Arial,sans-serif;color:#f0fff7;box-sizing:border-box}
    .pvz-tv-overlay *{box-sizing:border-box}
    .pvz-tv-overlay [hidden]{display:none!important}
    .pvz-tv-panel{width:100%;max-width:560px;max-height:90vh;overflow:auto;
      background:#192b27;border:2px solid #75d6a1;border-radius:14px;
      padding:22px;box-shadow:0 12px 28px #0008}
    .pvz-tv-panel h2{font-size:22px;line-height:1.25;margin:0 0 12px;color:#e3ffeb}
    .pvz-tv-panel p{font-size:16px;white-space:pre-wrap;margin:0 0 15px;color:#e3eae6}
    .pvz-tv-field{width:100%;font-size:20px;line-height:1.4;padding:12px;margin:0 0 10px;
      background:#fff;color:#18221b;border:2px solid #90daba;border-radius:8px}
    .pvz-tv-show{display:flex;align-items:center;gap:8px;margin:4px 0 14px;font-size:16px}
    .pvz-tv-show input{width:20px;height:20px}
    .pvz-tv-actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:12px}
    .pvz-tv-actions button{min-height:48px;padding:12px 18px;border:2px solid #8be0b2;
      border-radius:8px;background:#275943;color:#fff;font-size:18px;font-weight:600;cursor:pointer}
    .pvz-tv-actions button.pvz-tv-cancel{background:#303b37;border-color:#9aa9a1}
    .pvz-tv-actions button:focus,.pvz-tv-field:focus{outline:3px solid #ffe887;outline-offset:2px}
  `;

  function showTvDialog(title, message, kind = 'message', defaultValue = '') {
    return new Promise(resolve => {
      if (!$('pvz-tv-dialog-styles')) {
        const style = document.createElement('style');
        style.id = 'pvz-tv-dialog-styles';
        style.textContent = tvDialogStyles;
        document.head.appendChild(style);
      }
      const picker = $('server-picker-dialog');
      const pickerWasOpen = !!(picker && picker.open);
      if (pickerWasOpen) closePicker(); // Native <dialog> otherwise covers the inline overlay.
      const overlay = document.createElement('div');
      overlay.className = 'pvz-tv-overlay';
      overlay.setAttribute('role', 'presentation');
      overlay.innerHTML = '<div class="pvz-tv-panel" role="dialog" aria-modal="true" aria-labelledby="pvz-tv-dialog-title">' +
        '<h2 id="pvz-tv-dialog-title"></h2><p class="pvz-tv-message"></p>' +
        '<input class="pvz-tv-field" autocomplete="off" autocapitalize="off" spellcheck="false">' +
        '<label class="pvz-tv-show"><input type="checkbox"> Показати введений текст</label>' +
        '<div class="pvz-tv-actions"><button type="button" class="pvz-tv-ok">Підтвердити</button>' +
        '<button type="button" class="pvz-tv-cancel">Скасувати</button></div></div>';
      const field = overlay.querySelector('.pvz-tv-field');
      const showLabel = overlay.querySelector('.pvz-tv-show');
      const showCheckbox = showLabel.querySelector('input');
      const ok = overlay.querySelector('.pvz-tv-ok');
      const cancel = overlay.querySelector('.pvz-tv-cancel');
      overlay.querySelector('h2').textContent = title;
      overlay.querySelector('.pvz-tv-message').textContent = message;
      const needsInput = kind === 'token' || kind === 'text' || kind === 'copy';
      field.hidden = !needsInput;
      showLabel.hidden = kind !== 'token';
      field.type = kind === 'token' ? 'password' : 'text';
      field.value = defaultValue;
      field.readOnly = kind === 'copy';
      field.setAttribute('aria-label', title);
      if (kind === 'token') field.setAttribute('autocomplete', 'new-password');
      if (kind === 'message' || kind === 'copy') {
        ok.textContent = 'OK';
        cancel.hidden = true;
      }
      if (kind === 'confirm') ok.textContent = 'Так, продовжити';
      let finished = false;
      function finish(value) {
        if (finished) return;
        finished = true;
        document.removeEventListener('keydown', keyboard);
        overlay.remove();
        if (pickerWasOpen) displayPicker(picker);
        resolve(value);
      }
      function keyboard(event) {
        if (event.key === 'Escape' || event.key === 'Back' || event.key === 'BrowserBack') {
          event.preventDefault();
          finish(kind === 'confirm' ? false : null);
        } else if (event.key === 'Enter' && document.activeElement === field && kind !== 'copy') {
          event.preventDefault();
          ok.click();
        }
      }
      overlay.addEventListener('keydown', event => {
        if (event.key !== 'Escape' && event.key !== 'Back' && event.key !== 'BrowserBack') {
          event.stopPropagation();
        }
      });
      overlay.addEventListener('keyup', event => event.stopPropagation());
      overlay.addEventListener('keypress', event => event.stopPropagation());
      showCheckbox.addEventListener('change', () => {
        field.type = showCheckbox.checked ? 'text' : 'password';
        field.focus();
      });
      ok.addEventListener('click', () => {
        if (kind === 'token' && !field.value.trim()) {
          field.focus();
          return;
        }
        finish(kind === 'confirm' ? true : (needsInput ? field.value : true));
      });
      cancel.addEventListener('click', () => finish(kind === 'confirm' ? false : null));
      document.addEventListener('keydown', keyboard);
      document.body.appendChild(overlay);
      // Focus helps TV remotes open their soft keyboard; clicking the field also works.
      if (needsInput) field.focus();
      else ok.focus();
      if (kind === 'copy') field.select();
    });
  }

  window.pvzDialog = {
    notice: (msg, title) => tvNotice(msg, title),
    confirm: (msg, title) => tvConfirm(msg, title),
    ask: (msg, initial, title) => tvAsk(msg, initial, title)
  };

  function tvNotice(message, title = 'PvZ Portable') {
    return showTvDialog(title, message, 'message');
  }

  function tvConfirm(message, title = 'Підтвердь дію') {
    return showTvDialog(title, message, 'confirm');
  }

  function tvAsk(message, initial = '', title = 'Введення') {
    return showTvDialog(title, message, 'text', initial);
  }

  function readStorage(storageName, key) {
    try { return window[storageName].getItem(key); } catch { return null; }
  }

  function writeStorage(storageName, key, value) {
    try { window[storageName].setItem(key, value); return true; } catch { return false; }
  }

  function getSaveKey() {
    let key = readStorage('localStorage', saveKeyStorage) || fallbackSaveKey;
    if (!/^[0-9a-f]{64}$/i.test(key || '')) {
      const random = new Uint8Array(32);
      crypto.getRandomValues(random);
      key = Array.from(random, b => b.toString(16).padStart(2, '0')).join('');
      fallbackSaveKey = key;
      if (!writeStorage('localStorage', saveKeyStorage, key)) {
        setStatus('Browser storage unavailable: keep your recovery key to access server saves after reload.', true);
      }
    }
    return key;
  }

  function getAccessToken() {
    return readStorage('sessionStorage', apiTokenStorage) || fallbackApiToken;
  }

  function setStatus(message, error = false) {
    if (saveStatus) {
      saveStatus.textContent = message;
      saveStatus.classList.toggle('error', error);
    }
    const toolbarStatus = $('game-server-save-status');
    if (toolbarStatus) {
      toolbarStatus.textContent = message;
      toolbarStatus.classList.toggle('error', error);
    }
  }

  async function serverFetch(path, options = {}, interactive = true) {
    for (let attempt = 0; attempt < 2; attempt++) {
      const headers = new Headers(options.headers || {});
      headers.set('X-PvZ-Server-Token', getAccessToken());
      if (path.startsWith('/api/saves')) headers.set('X-PvZ-Save-Key', getSaveKey());
      let response;
      try {
        response = await fetch(path, { ...options, headers, cache: 'no-store', credentials: 'same-origin' });
      } catch (e) {
        throw new Error(`Network error while requesting ${path}: ${e && e.message ? e.message : String(e)}. Check the PC connection to server.py and its terminal log.`);
      }
      if (response.status === 401 && interactive && attempt === 0) {
        const token = await showTvDialog('Серверний токен',
          'Введи PVZ_SERVER_TOKEN для доступу до ресурсів і сейвів сервера.\n' +
          'Токен зберігатиметься лише в цій вкладці браузера.', 'token');
        if (token === null) throw new Error('Авторизацію скасовано.');
        fallbackApiToken = token.trim();
        writeStorage('sessionStorage', apiTokenStorage, fallbackApiToken);
        continue;
      }
      if (!response.ok) {
        let reason = '';
        try { reason = (await response.json()).error || ''; } catch { /* Static server returned HTML. */ }
        if (response.status === 404 && !reason) reason = 'Server API not available. Run server.py rather than a static file server.';
        throw new Error(reason || `HTTP ${response.status}`);
      }
      return response;
    }
    throw new Error('Server authorization failed.');
  }

  function readableSize(bytes) {
    return bytes >= 1048576 ? `${(bytes / 1048576).toFixed(1)} MiB` : `${Math.ceil(bytes / 1024)} KiB`;
  }

  function formatTime(value) {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '' : date.toLocaleString();
  }

  function openPicker(title, items, labelFunction, action, mode) {
    pickerMode = mode;
    selectedItems = items;
    $('server-picker-title').textContent = title;
    const select = $('server-picker-select');
    select.replaceChildren();
    for (let i = 0; i < items.length; i++) {
      const option = document.createElement('option');
      option.value = String(i);
      option.textContent = labelFunction(items[i], i);
      select.appendChild(option);
    }
    $('server-picker-apply-btn').textContent = action;
    $('server-picker-delete-btn').hidden = mode !== 'save';
    $('server-picker-history-btn').hidden = mode !== 'save';
    $('server-picker-back-btn').hidden = mode !== 'history';
    displayPicker($('server-picker-dialog'));
  }

  function displayPicker(picker) {
    if (typeof picker.showModal === 'function') {
      try { picker.showModal(); return; } catch (e) { /* Old TV WebView fallback below. */ }
    }
    picker.setAttribute('open', '');
    picker.style.display = 'block';
    picker.style.inset = '0';
    picker.style.margin = 'auto';
    picker.style.height = 'fit-content';
    picker.style.zIndex = '2147483646';
  }

  function closePicker() {
    const picker = $('server-picker-dialog');
    if (typeof picker.close === 'function' && picker.open) {
      try { picker.close(); } catch (e) { /* Fallback below. */ }
    }
    picker.removeAttribute('open');
    picker.style.display = '';
    picker.style.inset = '';
    picker.style.margin = '';
    picker.style.height = '';
    picker.style.zIndex = '';
  }

  async function busy(button, message, fn) {
    const old = button.textContent;
    button.disabled = true;
    button.textContent = message;
    try { await fn(); }
    catch (e) { console.error('PvZ server action:', e); setStatus(e.message || String(e), true); await tvNotice(e.message || String(e), 'Помилка сервера'); }
    finally { button.disabled = false; button.textContent = old; }
  }

  async function showResourcePicker() {
    const response = await serverFetch('/api/resources');
    const json = await response.json();
    const resources = Array.isArray(json.resources) ? json.resources : [];
    if (!resources.length) throw new Error('No resource ZIPs found on the server. Put a ZIP with main.pak and properties/ in server_data/resources/.');
    openPicker('Select game resources from server', resources,
      item => `${item.name} (${readableSize(item.size)})`, 'Load selected resources', 'resource');
  }

  // Avoid one fragile 30+ MiB fetch over LAN: request protected ZIP in 1 MiB
  // ranges, validating every response and retrying only the interrupted chunk.
  // No retry or token is placed in a URL, and server-side saves are untouched.
  async function downloadResourceArchive(item) {
    const path = `/api/resources/${encodeURIComponent(item.id)}`;
    const total = Number(item.size);
    if (!Number.isSafeInteger(total) || total <= 0 || total > 2 * 1024 * 1024 * 1024) {
      throw new Error('Server provided an invalid ZIP size.');
    }
    const chunkSize = 1024 * 1024;
    const chunks = [];
    let etag = '';
    for (let start = 0; start < total; start += chunkSize) {
      const end = Math.min(start + chunkSize, total) - 1;
      const expectedRange = `bytes ${start}-${end}/${total}`;
      let received = false;
      for (let attempt = 1; attempt <= 4; attempt++) {
        const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
        // Timeout is per 1 MiB chunk, not for the entire 33 MiB archive.
        const timeout = controller ? setTimeout(() => controller.abort(), 90000) : null;
        try {
          const headers = { Range: `bytes=${start}-${end}` };
          if (etag) headers['If-Range'] = etag;
          const response = await serverFetch(path, { headers, ...(controller ? { signal: controller.signal } : {}) });
          // Compatibility with older server.py versions without Range support.
          if (response.status === 200 && start === 0) {
            const blob = await response.blob();
            if (blob.size !== total) throw new Error(`Incomplete full ZIP: ${blob.size}/${total} bytes.`);
            setStatus(`Downloaded game resources: ${item.name} (100%).`);
            return blob;
          }
          if (response.status !== 206 || response.headers.get('Content-Range') !== expectedRange) {
            throw new Error('Server returned an unexpected ZIP byte range; verify server.py was updated.');
          }
          const chunkEtag = response.headers.get('ETag') || '';
          if (etag && chunkEtag && etag !== chunkEtag) {
            throw new Error('Server resource ZIP changed during download. Please restart the import.');
          }
          const part = await response.arrayBuffer();
          if (part.byteLength !== end - start + 1) {
            throw new Error(`Incomplete ZIP part: ${part.byteLength}/${end - start + 1} bytes.`);
          }
          if (!etag) etag = chunkEtag;
          chunks.push(new Uint8Array(part));
          received = true;
          setStatus(`Downloading ${item.name}: ${Math.floor((end + 1) * 100 / total)}% (${readableSize(end + 1)} / ${readableSize(total)})`);
          break;
        } catch (error) {
          const message = error && error.message ? error.message : String(error);
          if (/changed during download/.test(message)) throw error;
          if (attempt === 4) {
            throw new Error(`Server ZIP download failed at ${readableSize(start)} (part ${Math.floor(start / chunkSize) + 1}, 4 attempts): ${message}`);
          }
          setStatus(`Connection interrupted at ${Math.floor(start * 100 / total)}%. Retrying part (${attempt}/3)…`);
          await new Promise(resolve => setTimeout(resolve, 500 * attempt));
        } finally {
          if (timeout !== null) clearTimeout(timeout);
        }
      }
      if (!received) throw new Error('Resource download stopped before completion.');
    }
    return new Blob(chunks, { type: 'application/zip' });
  }

  async function loadSelectedResource(item) {
    const button = $('server-resource-btn');
    setStatus(`Downloading game resources: ${item.name}…`);
    const archive = await downloadResourceArchive(item);
    // Existing importResourceZip reads and validates resource paths and updates collectedFiles.
    const previousSelection = new Map(collectedFiles);
    collectedFiles.clear();
    try {
      await importResourceZip(archive, button, true);
      if (!collectedFiles.has('main.pak') || !Array.from(collectedFiles.keys()).some(n => n.startsWith('properties/'))) {
        throw new Error('Selected server archive does not contain usable main.pak and properties/ files.');
      }
    } catch (e) {
      collectedFiles.clear();
      for (const [path, file] of previousSelection) collectedFiles.set(path, file);
      refreshUI();
      throw e;
    }
    refreshUI();
    setStatus(`Game resources loaded from server: ${item.name}. Click Start Game.`);
  }

  async function listSaves() {
    const response = await serverFetch('/api/saves');
    const json = await response.json();
    return Array.isArray(json.saves) ? json.saves : [];
  }

  async function showSavePicker() {
    const saves = await listSaves();
    if (!saves.length) throw new Error('No saves found on the server for this browser recovery key.');
    openPicker('Import server local save', saves,
      item => `${item.slot} — ${formatTime(item.updated_at)} (${readableSize(item.size)}) · ${item.history_count || 0} older`,
      'Import selected save', 'save');
  }

  async function showHistoryPicker() {
    if (pickerMode !== 'save') return;
    const item = selectedItems[Number($('server-picker-select').value)];
    if (!item) return;
    // Viewing history never modifies the live server save or local browser data.
    const response = await serverFetch(`/api/saves/${encodeURIComponent(item.slot)}/history`);
    const result = await response.json();
    const versions = Array.isArray(result.history) ? result.history : [];
    if (!versions.length) {
      setStatus(`No older versions of “${item.slot}” yet. Backups appear after the next overwrite.`);
      await tvNotice(`Немає попередніх версій “${item.slot}”. Історія зʼявиться після перезапису слота.`);
      return;
    }
    closePicker();
    openPicker(`Previous backups — ${item.slot}`, versions.map(v => ({ ...v, slot: item.slot })),
      (v, i) => `#${i + 1} — ${formatTime(v.created_at)} (${readableSize(v.size)})`,
      'Restore this older backup', 'history');
  }

  async function backToSavePicker() {
    closePicker();
    await showSavePicker();
  }

  function safeSaveName(name) {
    return /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,39}$/.test(name);
  }

  async function createSaveZip() {
    await ensureSaveFsReady();
    await syncSaves();
    const files = collectSaveFiles('/saves/userdata');
    if (!files.length) throw new Error('No browser save files yet. Play the game and save your progress first.');
    const zip = new JSZip();
    for (const path of files) {
      const relative = path.replace(/^\/saves\//, '');
      if (!relative.startsWith('userdata/')) continue;
      zip.file(relative, Module.FS.readFile(path));
    }
    const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 6 } });
    if (blob.size > maxDownloadBytes) throw new Error('Save archive is larger than the server limit (16 MiB).');
    return blob;
  }

  async function uploadSave(slot = 'manual', interactive = true) {
    if (!safeSaveName(slot)) throw new Error('Save slot name must contain 1–40 letters, digits, underscores or hyphens.');
    if (serverUploadInProgress) {
      if (interactive) throw new Error('A server backup is already in progress.');
      return;
    }
    serverUploadInProgress = true;
    try {
      setStatus('Preparing browser saves for server upload…');
      const archive = await createSaveZip();
      setStatus(`Uploading ${readableSize(archive.size)} to server slot “${slot}”…`);
      await serverFetch(`/api/saves/${encodeURIComponent(slot)}`, {
        method: 'POST', headers: { 'Content-Type': 'application/zip' }, body: archive
      }, interactive);
      setStatus(`Server backup completed: ${slot} (${new Date().toLocaleTimeString()}).`);
    } finally { serverUploadInProgress = false; }
  }

  async function uploadManualSave() {
    const slot = await tvAsk('Назва серверного слота (наявний слот буде перезаписано):', 'manual', 'Назва сейву');
    if (slot === null) return;
    if (!safeSaveName(slot)) throw new Error('Use 1–40 ASCII letters, digits, _ or - for the save name.');
    if (!await tvConfirm(`Зберегти прогрес на сервері у слот “${slot}”?\nСтару поточну копію буде перенесено в історію.`)) return;
    await uploadSave(slot);
  }

  function normalizedImportedSavePath(name) {
    if (typeof name !== 'string' || name.includes('\\') || name.startsWith('/') || name.includes('\0')) return null;
    const parts = name.split('/');
    if (parts.length < 2 || parts[0] !== 'userdata' || parts.some(p => !p || p === '.' || p === '..')) return null;
    return parts.join('/');
  }

  async function importSelectedSave(item) {
    if (gameStarted) throw new Error('Exit the game before importing a server save.');
    const older = typeof item.revision === 'string' && /^[0-9]{20}-[0-9a-f]{12}$/.test(item.revision);
    const title = older ? `older backup of “${item.slot}” (${formatTime(item.created_at)})` : `server save “${item.slot}”`;
    if (!await tvConfirm(`Імпортувати ${title} в цей браузер?\nЛокальні файли з такими іменами буде замінено.\nПоточний серверний сейв не зміниться.`)) return;
    setStatus(`Downloading ${title}…`);
    const url = `/api/saves/${encodeURIComponent(item.slot)}` +
      (older ? `/history/${encodeURIComponent(item.revision)}` : '');
    const response = await serverFetch(url);
    const buffer = await response.arrayBuffer();
    if (buffer.byteLength > maxDownloadBytes) throw new Error('Server save archive is larger than 16 MiB.');
    const archive = await JSZip.loadAsync(buffer);
    const paths = Object.keys(archive.files).filter(n => !archive.files[n].dir);
    if (!paths.length || paths.length > 300) throw new Error('Invalid server save archive.');
    const entries = [];
    let total = 0;
    for (const name of paths) {
      const safe = normalizedImportedSavePath(name);
      if (!safe) throw new Error(`Unsafe path in server save archive: ${name}`);
      const data = await archive.files[name].async('uint8array');
      total += data.byteLength;
      if (total > 32 * 1024 * 1024) throw new Error('Save archive expands past the maximum allowed size.');
      entries.push([safe, data]);
    }
    await ensureSaveFsReady();
    for (const [path, data] of entries) {
      const absolute = '/saves/' + path;
      let parent = '';
      for (const segment of absolute.split('/').slice(1, -1)) {
        parent += '/' + segment;
        try { Module.FS.mkdir(parent); } catch (e) { if (!Module.FS.isDir(Module.FS.stat(parent).mode)) throw e; }
      }
      Module.FS.writeFile(absolute, data);
    }
    await syncSaves();
    setStatus(`Imported ${title} into this browser. Server copy unchanged.`);
    await tvNotice(`${title} імпортовано. Тепер можеш запускати гру. Серверний сейв не змінено.`);
  }

  async function deleteSelectedSave(item) {
    if (!await tvConfirm(`НАЗАВЖДИ видалити серверний сейв “${item.slot}” і всі 10 старих копій?\nЛокальні сейви браузера залишаться.`, 'Видалення сейву')) return;
    await serverFetch(`/api/saves/${encodeURIComponent(item.slot)}`, { method: 'DELETE' });
    setStatus(`Server save “${item.slot}” deleted.`);
  }

  async function applyPicker() {
    const item = selectedItems[Number($('server-picker-select').value)];
    if (!item) return;
    const mode = pickerMode;
    closePicker();
    const button = mode === 'resource' ? $('server-resource-btn') : $('server-save-import-btn');
    await busy(button, 'Working…', () => mode === 'resource' ? loadSelectedResource(item) : importSelectedSave(item));
  }

  async function deletePickerSave() {
    if (pickerMode !== 'save') return;
    const item = selectedItems[Number($('server-picker-select').value)];
    if (!item) return;
    closePicker();
    await busy($('server-save-import-btn'), 'Deleting…', () => deleteSelectedSave(item));
  }

  async function copyRecoveryKey() {
    const key = getSaveKey();
    try {
      await navigator.clipboard.writeText(key);
      setStatus('Recovery key copied. Keep it private: anyone with this key AND server access can restore your saves.');
    } catch {
      await showTvDialog('Recovery Key', 'Скопіюй ключ вручну та бережи його в таємниці:', 'copy', key);
    }
  }

  async function useRecoveryKey() {
    const key = $('server-recovery-input').value.trim().toLowerCase();
    if (!/^[0-9a-f]{64}$/.test(key)) {
      await tvNotice('Recovery Key має містити рівно 64 шістнадцяткові символи.');
      return;
    }
    if (!await tvConfirm('Перемкнутися на цей Recovery Key?\nСтарі серверні сейви залишаться за попереднім ключем. Обовʼязково збережи його.')) return;
    fallbackSaveKey = key;
    writeStorage('localStorage', saveKeyStorage, key);
    $('server-recovery-input').value = '';
    setStatus('Server save recovery key changed. Use Import Server Local Save to restore progress.');
  }

  // The user explicitly opts in each session; browser-only autosync remains unchanged.
  function toggleAutoBackup() {
    if (autoBackupTimer) { clearInterval(autoBackupTimer); autoBackupTimer = null; }
    if (!$('server-autobackup-checkbox').checked) {
      setStatus('Automatic server backup disabled. Saves still persist locally in your browser.');
      return;
    }
    setStatus('Automatic server backup enabled (every 2 minutes while this page is open).');
    autoBackupTimer = setInterval(async () => {
      if (!gameStarted || serverUploadInProgress) return;
      try { await uploadSave('autosave', false); }
      catch (e) {
        console.warn('Automatic server save failed:', e);
        setStatus(`Server autosave failed: ${e.message}`, true);
      }
    }, autoBackupEveryMs);
  }

  $('server-resource-btn').addEventListener('click', event => {
    event.stopPropagation();
    busy(event.currentTarget, 'Loading list…', showResourcePicker);
  });
  $('server-save-import-btn').addEventListener('click', event => busy(event.currentTarget, 'Loading list…', showSavePicker));
  $('server-save-upload-btn').addEventListener('click', event => busy(event.currentTarget, 'Uploading…', uploadManualSave));
  $('game-server-save-upload-btn').addEventListener('click', event => busy(event.currentTarget, 'Uploading…', uploadManualSave));
  $('server-picker-apply-btn').addEventListener('click', applyPicker);
  $('server-picker-delete-btn').addEventListener('click', deletePickerSave);
  $('server-picker-history-btn').addEventListener('click', event => busy(event.currentTarget, 'Loading history…', showHistoryPicker));
  $('server-picker-back-btn').addEventListener('click', event => busy(event.currentTarget, 'Loading…', backToSavePicker));
  $('server-picker-cancel-btn').addEventListener('click', closePicker);
  $('server-recovery-copy-btn').addEventListener('click', copyRecoveryKey);
  $('server-recovery-use-btn').addEventListener('click', useRecoveryKey);
  $('server-autobackup-checkbox').addEventListener('change', toggleAutoBackup);
  getSaveKey();
})();
